import React from 'react';
declare const ArrowForwardIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default ArrowForwardIcon;
//# sourceMappingURL=ArrowForwardIcon.d.ts.map