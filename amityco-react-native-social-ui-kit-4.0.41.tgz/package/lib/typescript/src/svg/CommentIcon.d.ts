import React from 'react';
declare const CommentIcon: ({ width, height, color, style, }: {
    width?: number;
    height?: number;
    color?: string;
    style?: any;
}) => React.JSX.Element;
export default CommentIcon;
//# sourceMappingURL=CommentIcon.d.ts.map