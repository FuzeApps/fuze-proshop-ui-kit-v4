import React from 'react';
import { SvgProps } from 'react-native-svg';
interface ReportIconProps extends SvgProps {
    color?: string;
}
declare const ReportIcon: React.FC<ReportIconProps>;
export default ReportIcon;
//# sourceMappingURL=ReportIcon.d.ts.map