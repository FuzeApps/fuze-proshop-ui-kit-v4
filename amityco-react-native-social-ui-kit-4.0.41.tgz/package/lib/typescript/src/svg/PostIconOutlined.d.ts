import React from 'react';
export declare const PostIconOutlined: ({ color, width, height, }: {
    color?: string;
    width?: number;
    height?: number;
}) => React.JSX.Element;
//# sourceMappingURL=PostIconOutlined.d.ts.map