import React from 'react';
declare const ShieldIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: {};
}) => React.JSX.Element;
export default ShieldIcon;
//# sourceMappingURL=ShieldIcon.d.ts.map