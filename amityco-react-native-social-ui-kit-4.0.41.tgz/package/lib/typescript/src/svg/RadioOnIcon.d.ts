import React from 'react';
declare const RadioOnIcon: ({ color, width, height, }: {
    color?: string;
    width?: number;
    height?: number;
}) => React.JSX.Element;
export default RadioOnIcon;
//# sourceMappingURL=RadioOnIcon.d.ts.map