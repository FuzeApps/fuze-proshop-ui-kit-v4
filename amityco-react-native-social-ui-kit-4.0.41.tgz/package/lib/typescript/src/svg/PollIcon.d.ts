import React from 'react';
export declare const PollIcon: ({ color, width, height, }: {
    color?: string;
    width?: number;
    height?: number;
}) => React.JSX.Element;
//# sourceMappingURL=PollIcon.d.ts.map