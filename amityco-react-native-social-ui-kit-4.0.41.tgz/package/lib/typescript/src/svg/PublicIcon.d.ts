import React from 'react';
declare const PublicIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default PublicIcon;
//# sourceMappingURL=PublicIcon.d.ts.map