import React from 'react';
declare const UserIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default UserIcon;
//# sourceMappingURL=UserIcon.d.ts.map