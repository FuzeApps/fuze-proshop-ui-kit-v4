import React from 'react';
declare const ArrowBackIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default ArrowBackIcon;
//# sourceMappingURL=ArrowBackIcon.d.ts.map