import React from 'react';
declare const EditIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default EditIcon;
//# sourceMappingURL=EditIcon.d.ts.map