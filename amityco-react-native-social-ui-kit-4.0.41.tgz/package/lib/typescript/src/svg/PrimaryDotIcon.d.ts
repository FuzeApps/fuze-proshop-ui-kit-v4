import React from 'react';
declare const PrimaryDot: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default PrimaryDot;
//# sourceMappingURL=PrimaryDotIcon.d.ts.map