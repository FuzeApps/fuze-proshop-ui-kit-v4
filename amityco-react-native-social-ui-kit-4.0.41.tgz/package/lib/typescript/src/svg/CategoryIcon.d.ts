import React from 'react';
declare const CategoryIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default CategoryIcon;
//# sourceMappingURL=CategoryIcon.d.ts.map