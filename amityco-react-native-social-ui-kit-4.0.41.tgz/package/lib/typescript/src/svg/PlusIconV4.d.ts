import React from 'react';
declare const PlusIconV4: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: {};
}) => React.JSX.Element;
export default PlusIconV4;
//# sourceMappingURL=PlusIconV4.d.ts.map