import React from 'react';
declare const SearchIconV4: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: {};
}) => React.JSX.Element;
export default SearchIconV4;
//# sourceMappingURL=SearchIconV4.d.ts.map