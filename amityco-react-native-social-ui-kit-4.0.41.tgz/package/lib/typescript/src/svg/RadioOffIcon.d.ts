import React from 'react';
declare const RadioOffIcon: ({ color, width, height, }: {
    color?: string;
    width?: number;
    height?: number;
}) => React.JSX.Element;
export default RadioOffIcon;
//# sourceMappingURL=RadioOffIcon.d.ts.map