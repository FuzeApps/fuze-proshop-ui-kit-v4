import React from 'react';
export declare const LikedIcon: ({ color, width, height, }: {
    color?: string;
    width?: number;
    height?: number;
}) => React.JSX.Element;
//# sourceMappingURL=LikedIcon.d.ts.map