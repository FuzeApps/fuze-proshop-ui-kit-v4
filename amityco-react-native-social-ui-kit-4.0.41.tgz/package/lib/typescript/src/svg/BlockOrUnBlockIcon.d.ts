import React from 'react';
import { SvgProps } from 'react-native-svg';
interface BlockOrUnblockIconProps extends SvgProps {
    color?: string;
}
declare const BlockOrUnblockIcon: React.FC<BlockOrUnblockIconProps>;
export default BlockOrUnblockIcon;
//# sourceMappingURL=BlockOrUnBlockIcon.d.ts.map