import React from 'react';
import { SvgProps } from 'react-native-svg';
interface UnfollowIconProps extends SvgProps {
    color?: string;
}
declare const UnfollowIcon: React.FC<UnfollowIconProps>;
export default UnfollowIcon;
//# sourceMappingURL=UnfollowIcon.d.ts.map