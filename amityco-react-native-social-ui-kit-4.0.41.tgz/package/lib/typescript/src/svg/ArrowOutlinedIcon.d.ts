import React from 'react';
declare const ArrowOutlinedIcon: ({ width, height, color }: {
    width?: number;
    height?: number;
    color?: string;
}) => React.JSX.Element;
export default ArrowOutlinedIcon;
//# sourceMappingURL=ArrowOutlinedIcon.d.ts.map