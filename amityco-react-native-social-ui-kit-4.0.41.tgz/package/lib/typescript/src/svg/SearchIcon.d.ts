import React from 'react';
export declare const SearchIcon: ({ color, width, height, }: {
    color?: string;
    width?: number;
    height?: number;
}) => React.JSX.Element;
//# sourceMappingURL=SearchIcon.d.ts.map