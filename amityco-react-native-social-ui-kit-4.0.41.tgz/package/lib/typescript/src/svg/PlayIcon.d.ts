import React from 'react';
declare const PlayIcon: ({ width, height }: {
    width?: number;
    height?: number;
}) => React.JSX.Element;
export default PlayIcon;
//# sourceMappingURL=PlayIcon.d.ts.map