import React from 'react';
declare const ExpandIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default ExpandIcon;
//# sourceMappingURL=ExpandIcon.d.ts.map