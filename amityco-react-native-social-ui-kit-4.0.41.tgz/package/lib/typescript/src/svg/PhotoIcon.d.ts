import React from 'react';
import { SvgProps } from 'react-native-svg';
interface PhotoIconProps extends SvgProps {
    color?: string;
}
declare const PhotoIcon: React.FC<PhotoIconProps>;
export default PhotoIcon;
//# sourceMappingURL=PhotoIcon.d.ts.map