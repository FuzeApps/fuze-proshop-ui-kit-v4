import React from 'react';
declare const CircleCloseIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default CircleCloseIcon;
//# sourceMappingURL=CircleCloseIcon.d.ts.map