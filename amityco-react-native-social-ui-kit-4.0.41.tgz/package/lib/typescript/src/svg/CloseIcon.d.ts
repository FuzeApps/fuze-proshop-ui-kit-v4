import React from 'react';
declare const CloseIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default CloseIcon;
//# sourceMappingURL=CloseIcon.d.ts.map