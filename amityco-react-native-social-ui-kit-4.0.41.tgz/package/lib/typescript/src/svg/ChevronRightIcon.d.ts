import React from 'react';
import { SvgProps } from 'react-native-svg';
interface ChevronRightIconProps extends SvgProps {
    color?: string;
    width?: number;
    height?: number;
}
export declare const ChevronRightIcon: React.FC<ChevronRightIconProps>;
export {};
//# sourceMappingURL=ChevronRightIcon.d.ts.map