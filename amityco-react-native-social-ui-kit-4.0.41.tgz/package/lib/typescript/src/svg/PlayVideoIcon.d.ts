import React from 'react';
declare const PlayVideoIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default PlayVideoIcon;
//# sourceMappingURL=PlayVideoIcon.d.ts.map