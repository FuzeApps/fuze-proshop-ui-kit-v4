import React from 'react';
declare const LikeReactionIcon: ({ width, height, circleColor, style, }: {
    width?: number;
    height?: number;
    circleColor?: string;
    style?: {};
}) => React.JSX.Element;
export default LikeReactionIcon;
//# sourceMappingURL=LikeReactionIcon.d.ts.map