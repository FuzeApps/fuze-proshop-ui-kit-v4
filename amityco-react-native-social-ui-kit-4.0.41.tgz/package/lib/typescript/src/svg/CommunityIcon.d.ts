import React from 'react';
declare const CommunityIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default CommunityIcon;
//# sourceMappingURL=CommunityIcon.d.ts.map