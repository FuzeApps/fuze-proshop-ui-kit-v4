import React from 'react';
interface StoryRingProps {
    colorOne?: string;
    colorTwo?: string;
    width?: number;
    height?: number;
}
declare const StoryRing: React.FC<StoryRingProps>;
export default StoryRing;
//# sourceMappingURL=StoryRing.d.ts.map