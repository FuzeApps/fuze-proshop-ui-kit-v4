import React from 'react';
export declare const PostArrowIcon: ({ width, height, color }: {
    width?: number;
    height?: number;
    color?: string;
}) => React.JSX.Element;
export default PostArrowIcon;
//# sourceMappingURL=PostArrowIcon.d.ts.map