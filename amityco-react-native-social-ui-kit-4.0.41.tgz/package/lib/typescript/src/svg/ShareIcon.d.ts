import React from 'react';
declare const ShareIcon: ({ width, height, color, style, }: {
    width?: number;
    height?: number;
    color?: string;
    style?: any;
}) => React.JSX.Element;
export default ShareIcon;
//# sourceMappingURL=ShareIcon.d.ts.map