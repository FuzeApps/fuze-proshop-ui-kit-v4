import React from 'react';
declare const ChevronLeftIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: {};
}) => React.JSX.Element;
export default ChevronLeftIcon;
//# sourceMappingURL=ChevronLeftcon.d.ts.map