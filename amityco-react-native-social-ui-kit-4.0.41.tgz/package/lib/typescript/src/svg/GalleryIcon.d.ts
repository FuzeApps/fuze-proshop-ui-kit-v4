import React from 'react';
declare const GalleryIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default GalleryIcon;
//# sourceMappingURL=GalleryIcon.d.ts.map