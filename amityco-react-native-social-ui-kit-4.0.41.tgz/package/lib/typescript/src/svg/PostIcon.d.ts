import React from 'react';
declare const PostIcon: ({ color }: {
    color?: string;
}) => React.JSX.Element;
export default PostIcon;
//# sourceMappingURL=PostIcon.d.ts.map