import React from 'react';
export declare const ThreeDotsIcon: ({ color, style, }: {
    color?: string;
    style?: any;
}) => React.JSX.Element;
//# sourceMappingURL=ThreeDotsIcon.d.ts.map