import React from 'react';
declare const PersonIcon: ({ width, height, color }: {
    width?: number;
    height?: number;
    color?: string;
}) => React.JSX.Element;
export default PersonIcon;
//# sourceMappingURL=PersonIcon.d.ts.map