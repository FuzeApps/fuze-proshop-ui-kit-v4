import React from 'react';
declare const ArrowDownIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default ArrowDownIcon;
//# sourceMappingURL=ArrowDownIcon.d.ts.map