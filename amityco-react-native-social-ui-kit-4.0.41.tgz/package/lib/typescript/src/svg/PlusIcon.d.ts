import React from 'react';
import { SvgProps } from 'react-native-svg';
interface PlusIconProps extends SvgProps {
    color?: string;
}
export declare const PlusIcon: React.FC<PlusIconProps>;
export {};
//# sourceMappingURL=PlusIcon.d.ts.map