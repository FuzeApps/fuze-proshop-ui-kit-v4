import React from 'react';
declare const ReplyIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default ReplyIcon;
//# sourceMappingURL=ReplyIcon.d.ts.map