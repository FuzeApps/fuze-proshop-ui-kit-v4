import React from 'react';
export declare const LikeIcon: ({ color, width, height }: {
    color?: string;
    width?: number;
    height?: number;
}) => React.JSX.Element;
//# sourceMappingURL=LikeIcon.d.ts.map