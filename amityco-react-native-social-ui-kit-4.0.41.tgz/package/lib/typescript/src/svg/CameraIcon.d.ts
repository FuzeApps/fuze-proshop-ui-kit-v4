import React from 'react';
declare const CameraIcon: ({ color, width, height, style, }: {
    color?: string;
    width?: number;
    height?: number;
    style?: any;
}) => React.JSX.Element;
export default CameraIcon;
//# sourceMappingURL=CameraIcon.d.ts.map