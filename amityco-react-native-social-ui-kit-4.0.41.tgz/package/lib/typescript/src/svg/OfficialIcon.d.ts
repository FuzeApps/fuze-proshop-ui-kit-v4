import React from 'react';
import { SvgProps } from 'react-native-svg';
interface OfficialIconProps extends SvgProps {
    color?: string;
}
declare const OfficialIcon: React.FC<OfficialIconProps>;
export default OfficialIcon;
//# sourceMappingURL=OfficialIcon.d.ts.map