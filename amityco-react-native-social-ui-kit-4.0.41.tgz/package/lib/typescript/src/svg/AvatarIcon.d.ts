import React from 'react';
export declare const AvatarIcon: ({ width, height, color, }: {
    color?: string;
    width?: number;
    height?: number;
}) => React.JSX.Element;
//# sourceMappingURL=AvatarIcon.d.ts.map