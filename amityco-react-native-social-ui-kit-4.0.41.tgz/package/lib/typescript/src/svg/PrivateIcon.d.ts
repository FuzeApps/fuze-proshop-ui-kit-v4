import React from 'react';
declare const PrivateIcon: ({ width, height, color, }: {
    width?: number;
    height?: number;
    color?: string;
}) => React.JSX.Element;
export default PrivateIcon;
//# sourceMappingURL=PrivateIcon.d.ts.map