export declare const defaultAvatarUri: any;
export declare const defaultCommunityAvatarUri: any;
//# sourceMappingURL=index.d.ts.map