import * as React from 'react';
import { DefaultTheme, type MD3Theme } from 'react-native-paper';
import { UserRole } from '../enum';
import { IBehaviour } from '../types/behaviour.interface';
import { IConfigRaw } from '../types/config.interface';
export type CusTomTheme = typeof DefaultTheme;
export interface IAmityUIkitProvider {
    userId: string;
    displayName?: string;
    apiKey: string;
    apiRegion?: string;
    apiEndpoint?: string;
    children: any;
    authToken?: string;
    configs?: IConfigRaw;
    behaviour?: IBehaviour;
    userRole?: UserRole;
    minMembersToShowCounter?: number;
    onUserFollow?: (data: {
        userId?: string;
        userName?: string;
    }) => void;
    onUserUnFollow?: (data: {
        userId?: string;
        userName?: string;
    }) => void;
    onViewMyProShop?: (data: {
        userId?: string;
        userName?: string;
    }) => void;
    onCommunityJoin?: (data: {
        communityName?: string;
        communityId?: string;
    }) => void;
    onCommunityLeave?: (data: {
        communityName?: string;
        communityId?: string;
        userId?: string;
    }) => void;
    onCommunityCreate?: (data: {
        communityName?: string;
        communityId?: string;
        userId?: string;
    }) => void;
    onCommunityDelete?: (data: {
        communityName?: string;
        communityId?: string;
        userId?: string;
    }) => void;
    onPostLike?: (data: {
        text?: string;
        postId?: string;
    }) => void;
    onPostUnLike?: (data: {
        text?: string;
        postId?: string;
    }) => void;
    onPostStart?: (data: {
        text?: string;
        postId?: string;
        userId?: string;
        userName?: string;
        communityId?: string;
        communityName?: string;
        targetType?: string;
    }) => void;
    onPostComplete?: (data: {
        text?: string;
        postId?: string;
        userId?: string;
        userName?: string;
        communityId?: string;
        communityName?: string;
        targetType?: string;
    }) => void;
    CommunityLeaderboardComponent?: (props: {
        communityId: string;
    }) => JSX.Element;
}
export interface CustomColors {
    primary?: string;
    primaryShade1?: string;
    primaryShade2?: string;
    primaryShade3?: string;
    primaryShade4?: string;
    secondary?: string;
    secondaryShade1?: string;
    secondaryShade2?: string;
    secondaryShade3?: string;
    secondaryShade4?: string;
    base?: string;
    baseShade1?: string;
    baseShade2?: string;
    baseShade3?: string;
    baseShade4?: string;
    background?: string;
    backgroundShade1?: string;
    alert?: string;
    border?: string;
    screenBackground?: string;
    baseDivider?: string;
}
export interface MyMD3Theme extends MD3Theme {
    colors: MD3Theme['colors'] & CustomColors;
}
export default function AmityUiKitProvider({ userId, displayName, apiKey, apiRegion, apiEndpoint, children, authToken, configs, behaviour, CommunityLeaderboardComponent, onCommunityJoin, onCommunityLeave, onPostComplete, onPostLike, onPostStart, onPostUnLike, onUserFollow, onUserUnFollow, onViewMyProShop, onCommunityCreate, onCommunityDelete, userRole, minMembersToShowCounter, }: IAmityUIkitProvider): React.JSX.Element;
//# sourceMappingURL=amity-ui-kit-provider.d.ts.map