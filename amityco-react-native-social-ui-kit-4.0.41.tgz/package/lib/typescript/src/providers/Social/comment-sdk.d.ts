import { IMentionPosition } from '../../types/type';
export interface ICommentRes {
    data: Amity.Comment[];
    onNextPage: () => any;
    unsubscribe: () => any;
    hasNextPage: boolean;
}
export declare function addCommentReaction(commentId: string, reactionName: string): Promise<boolean>;
export declare function removeCommentReaction(commentId: string, reactionName: string): Promise<boolean>;
export declare function createComment(text: string, postId: string, mentionUserIds: string[], mentionPosition: IMentionPosition[], referenceType: Amity.CommentReferenceType): Promise<Amity.InternalComment>;
export declare function createReplyComment(text: string, postId: string, parentId: string, mentionUserIds: string[], mentionPosition: IMentionPosition[], referenceType: Amity.CommentReferenceType): Promise<Amity.InternalComment>;
export declare function editComment(text: string, commentId: string, referenceType: Amity.CommentReferenceType): Promise<Amity.InternalComment>;
export declare function getCommentsDataByIds(commentIds: string[]): Promise<Amity.InternalComment[]>;
export declare function deleteCommentById(commentId: string): Promise<boolean>;
//# sourceMappingURL=comment-sdk.d.ts.map