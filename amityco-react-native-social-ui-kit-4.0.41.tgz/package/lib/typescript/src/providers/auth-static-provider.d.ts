import React, { FC } from 'react';
import { IAmityUIkitProvider } from './amity-ui-kit-provider';
export declare const AuthStaticContext: React.Context<IAmityUIkitProvider>;
export declare const AuthStaticProvider: FC<IAmityUIkitProvider>;
export default AuthStaticProvider;
//# sourceMappingURL=auth-static-provider.d.ts.map