import React from 'react';
export default function CommunityList({ navigation, route }: any): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map