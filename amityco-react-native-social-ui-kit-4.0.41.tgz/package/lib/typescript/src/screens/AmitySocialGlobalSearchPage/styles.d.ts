import type { MyMD3Theme } from '../../providers/amity-ui-kit-provider';
export declare const useStyles: (theme: MyMD3Theme) => {
    container: {
        backgroundColor: string;
        flex: number;
    };
    searchScrollList: {
        paddingBottom: number;
        marginTop: number;
    };
    notFoundText: {
        marginTop: number;
        fontSize: number;
        alignSelf: "center";
        textAlign: "center";
        color: string;
    };
    searchEmptyContainer: {
        flex: number;
        justifyContent: "center";
        alignItems: "center";
    };
    iconWrapper: {
        backgroundColor: string;
        width: number;
        height: number;
        justifyContent: "center";
        alignItems: "center";
        borderRadius: number;
        marginBottom: number;
    };
    searchEmptyText: {
        color: string;
        fontSize: number;
        lineHeight: number;
    };
};
//# sourceMappingURL=styles.d.ts.map