import type { MyMD3Theme } from '../../providers/amity-ui-kit-provider';
export declare const useStyles: (theme: MyMD3Theme) => {
    container: {
        flex: number;
        backgroundColor: string;
    };
    headerContainer: {
        flexDirection: "row";
        justifyContent: "space-between";
        paddingHorizontal: number;
        alignItems: "center";
        marginTop: number;
    };
    closeBtn: {
        width: number;
        height: number;
    };
    title: {
        color: string;
        fontSize: number;
        fontWeight: "bold";
    };
    activePostBtn: {
        color: string;
        opacity: number;
    };
    postBtnText: {
        color: string;
        fontSize: number;
        opacity: number;
    };
    inputWrapper: {
        flex: number;
        paddingVertical: number;
        paddingHorizontal: number;
    };
    scrollContainer: {
        height: number;
    };
    imageContainer: {
        flexDirection: "row";
        flex: number;
        marginTop: number;
        paddingBottom: number;
    };
};
//# sourceMappingURL=styles.d.ts.map