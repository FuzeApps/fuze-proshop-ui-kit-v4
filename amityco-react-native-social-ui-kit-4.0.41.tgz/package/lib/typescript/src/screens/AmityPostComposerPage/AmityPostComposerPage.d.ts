import React from 'react';
import { AmityPostComposerPageType } from '../../types/global.interface';
declare const _default: React.NamedExoticComponent<AmityPostComposerPageType>;
export default _default;
//# sourceMappingURL=AmityPostComposerPage.d.ts.map