import React from 'react';
export default function CommunityMemberDetail({ route }: any): React.JSX.Element;
//# sourceMappingURL=CommunityMemberDetail.d.ts.map