import React from 'react';
interface IMemberActionModal {
    isVisible: boolean;
    setIsVisible: (isVisible: boolean) => void;
    userId: string;
    communityId: string;
    hasModeratorPermission: boolean;
    isInModeratorTab: boolean;
}
declare const _default: React.NamedExoticComponent<IMemberActionModal>;
export default _default;
//# sourceMappingURL=MemberActionModal.d.ts.map