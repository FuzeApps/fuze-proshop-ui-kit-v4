import * as React from 'react';
declare const EditCommunity: ({ navigation, route }: {
    navigation: any;
    route: any;
}) => React.JSX.Element;
export default EditCommunity;
//# sourceMappingURL=EditCommunity.d.ts.map