import React from 'react';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../routes/RouteParamList';
type FollowerListType = {
    route: RouteProp<RootStackParamList, 'FollowerList'>;
};
declare const _default: React.NamedExoticComponent<FollowerListType>;
export default _default;
//# sourceMappingURL=FollowerList.d.ts.map