export declare const useStyles: () => {
    container: {
        flex: number;
        width: number;
        alignSelf: "center";
        backgroundColor: string;
        padding: number;
    };
    listItemContainer: {
        flexDirection: "row";
        padding: number;
        justifyContent: "space-between";
        alignItems: "center";
    };
    userInfoContainer: {
        flexDirection: "row";
        alignItems: "center";
        flex: number;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        backgroundColor: string;
        marginRight: number;
    };
    defaultAvatar: {
        marginRight: number;
    };
    userName: {
        color: string;
        fontSize: number;
        fontWeight: "600";
    };
    menuBtn: {
        paddingLeft: number;
    };
    modalContainer: {
        flex: number;
        justifyContent: "flex-end";
        backgroundColor: string;
        minHeight: number;
        paddingBottom: number;
    };
    modalContent: {
        backgroundColor: string;
        borderTopLeftRadius: number;
        borderTopRightRadius: number;
        padding: number;
        minHeight: number;
    };
    report: {
        fontSize: number;
        color: string;
        fontWeight: "600";
        marginBottom: number;
    };
    remove: {
        fontSize: number;
        color: string;
        fontWeight: "600";
        marginBottom: number;
    };
};
//# sourceMappingURL=styles.d.ts.map