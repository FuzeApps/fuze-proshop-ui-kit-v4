import React from 'react';
declare const CreatePoll: ({ navigation, route }: {
    navigation: any;
    route: any;
}) => React.JSX.Element;
export default CreatePoll;
//# sourceMappingURL=CreatePoll.d.ts.map