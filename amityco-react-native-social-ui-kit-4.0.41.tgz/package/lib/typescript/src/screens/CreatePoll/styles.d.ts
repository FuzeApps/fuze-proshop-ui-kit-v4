export declare const useStyles: () => {
    barContainer: {
        backgroundColor: string;
        borderBottomColor: string;
        borderBottomWidth: number;
    };
    header: {
        zIndex: number;
        padding: number;
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
    };
    closeButton: {
        padding: number;
        zIndex: number;
        left: number;
    };
    headerTextContainer: {
        flex: number;
        alignItems: "center";
        justifyContent: "center";
    };
    headerText: {
        fontWeight: "600";
        fontSize: number;
        textAlign: "center";
        color: string;
    };
    postText: {
        fontWeight: "400";
        fontSize: number;
        textAlign: "center";
        color: string;
    };
    disabled: {
        opacity: number;
        color: string;
    };
    AllInputWrap: {
        backgroundColor: string;
        flex: number;
    };
    inputTitle: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    requiredField: {
        color: string;
    };
    maxPollQuestionText: {
        color: string;
    };
    inputContainer: {
        margin: number;
        borderBottomColor: string;
        borderBottomWidth: number;
        paddingBottom: number;
    };
    mentionInputContainer: {
        marginTop: number;
    };
    rowContainer: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
    };
    input: {
        marginTop: number;
        width: "100%";
        color: string;
    };
    errorText: {
        color: string;
    };
    subtitle: {
        fontSize: number;
        color: string;
        marginTop: number;
        marginBottom: number;
    };
    addOptionBtn: {
        borderRadius: number;
        borderColor: string;
        borderWidth: number;
        width: "100%";
        padding: number;
        justifyContent: "center";
        alignItems: "center";
        marginTop: number;
        flexDirection: "row";
    };
    addOptionText: {
        color: string;
        fontSize: number;
        fontWeight: "bold";
    };
    fillSpace: {
        flex: number;
    };
    optionInput: {
        flex: number;
        padding: number;
        fontSize: number;
        color: string;
    };
    scrollContainer: {
        paddingVertical: number;
    };
    pollOptionContainer: {
        borderRadius: number;
        backgroundColor: string;
        paddingHorizontal: number;
        paddingVertical: number;
        marginVertical: number;
    };
    scheduleOptionContainer: {
        maxHeight: number;
        backgroundColor: string;
    };
    scheduleOptionText: {
        color: string;
    };
    scheduleSelectorSelectStyle: {
        alignItems: "flex-start";
        marginTop: number;
        borderWidth: number;
    };
    selectedTimeFrame: {
        color: string;
    };
    scheduleTitleStyle: {
        fontWeight: "bold";
        fontSize: number;
        alignSelf: "flex-start";
        marginBottom: number;
        color: string;
    };
    scheduleInitValueTextStyle: {
        color: string;
    };
    scheduleOptionStyle: {
        borderBottomWidth: number;
        marginVertical: number;
        backgroundColor: string;
        borderRadius: number;
    };
    scheduleSectionStyle: {
        borderBottomWidth: number;
    };
    scheduleSelectedItemText: {
        color: string;
    };
    optionWordCount: {
        alignSelf: "flex-end";
        color: string;
        fontSize: number;
    };
};
//# sourceMappingURL=styles.d.ts.map