export declare const useStyle: () => {
    feedWrap: {
        backgroundColor: string;
        height: "100%";
    };
};
//# sourceMappingURL=styles.d.ts.map