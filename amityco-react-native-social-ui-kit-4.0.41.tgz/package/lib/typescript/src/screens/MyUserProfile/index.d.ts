import React from 'react';
export default function MyUserprofile(): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map