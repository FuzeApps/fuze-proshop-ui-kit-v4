export declare const useStyles: () => {
    container: {
        flex: number;
        backgroundColor: string;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginBottom: number;
        backgroundColor: string;
    };
    joinContainer: {
        flex: number;
        justifyContent: "center";
        alignItems: "center";
        marginVertical: number;
    };
    joinCommunityButton: {
        backgroundColor: string;
        width: "90%";
        padding: number;
        borderRadius: number;
        flexDirection: "row";
        justifyContent: "center";
        alignItems: "center";
    };
    joinCommunityText: {
        marginLeft: number;
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    dotIcon: {
        width: number;
        height: number;
    };
    imageContainer: {
        width: "100%";
        height: number;
    };
    image: {
        width: "100%";
        height: "100%";
    };
    emptyImage: {
        width: "100%";
        height: "100%";
        backgroundColor: string;
    };
    darkOverlay: {
        backgroundColor: string;
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    overlay: {
        position: "absolute";
        bottom: number;
        left: number;
        right: number;
        backgroundColor: string;
        padding: number;
    };
    overlayCommunityText: {
        color: string;
        fontWeight: "bold";
        fontSize: number;
        marginBottom: number;
        textShadowColor: string;
        textShadowOffset: {
            width: number;
            height: number;
        };
        textShadowRadius: number;
    };
    joinIcon: {
        width: number;
        height: number;
        color: string;
    };
    overlayCategoryText: {
        color: string;
        fontWeight: "400";
        fontSize: number;
    };
    row: {
        flexDirection: "row";
        justifyContent: "flex-start";
        height: number;
        marginVertical: number;
        paddingHorizontal: number;
    };
    rowItem: {
        alignItems: "flex-start";
        justifyContent: "flex-start";
    };
    rowItemContent: {
        flexDirection: "row";
        paddingLeft: number;
    };
    verticalLine: {
        height: number;
        width: number;
        backgroundColor: string;
        marginHorizontal: number;
    };
    rowNumber: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    rowLabel: {
        fontSize: number;
        color: string;
    };
    textComponent: {
        fontSize: number;
        paddingVertical: number;
        paddingHorizontal: number;
        color: string;
    };
    pendingPostWrap: {
        paddingVertical: number;
        display: "flex";
        justifyContent: "center";
        alignItems: "center";
        marginHorizontal: number;
    };
    pendingPostArea: {
        width: "100%";
        height: number;
        backgroundColor: string;
        paddingVertical: number;
        alignItems: "center";
        borderRadius: number;
    };
    pendingText: {
        fontSize: number;
        fontWeight: "600";
        color: string;
        marginLeft: number;
    };
    pendingDescriptionText: {
        fontSize: number;
        fontWeight: "400";
        color: string;
    };
    pendingRow: {
        flexDirection: "row";
        alignItems: "center";
    };
    editProfileButton: {
        width: "98%";
        borderWidth: number;
        borderColor: string;
        padding: number;
        borderRadius: number;
        flexDirection: "row";
        justifyContent: "center";
        alignItems: "center";
        alignSelf: "center";
        marginTop: number;
    };
    editProfileText: {
        marginLeft: number;
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    tabBackground: {
        backgroundColor: string;
        flex: number;
    };
};
//# sourceMappingURL=styles.d.ts.map