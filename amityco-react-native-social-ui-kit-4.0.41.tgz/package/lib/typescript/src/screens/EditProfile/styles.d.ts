export declare const useStyles: () => {
    container: {
        flex: number;
        alignItems: "center";
        paddingHorizontal: number;
        backgroundColor: string;
    };
    avatarContainer: {
        position: "relative";
        marginBottom: number;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
    };
    overlay: {
        justifyContent: "center";
        alignItems: "center";
        zIndex: number;
        backgroundColor: string;
    };
    cameraIconContainer: {
        position: "absolute";
        bottom: number;
        right: number;
    };
    cameraIcon: {
        backgroundColor: string;
        borderRadius: number;
        padding: number;
        margin: number;
    };
    imageIcon: {};
    displayNameContainer: {
        flexDirection: "row";
        alignItems: "center";
        marginTop: number;
        marginBottom: number;
    };
    displayNameText: {
        flex: number;
        fontWeight: "600";
        fontSize: number;
    };
    characterCountContainer: {
        marginRight: number;
    };
    characterCountText: {
        fontSize: number;
        color: string;
    };
    input: {
        width: "100%";
        height: number;
        padding: number;
        borderBottomWidth: number;
        borderRadius: number;
        borderColor: string;
        fontSize: number;
    };
};
//# sourceMappingURL=styles.d.ts.map