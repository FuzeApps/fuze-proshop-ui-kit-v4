import React from 'react';
interface EditProfileProps {
    navigation: any;
    route: any;
}
export declare const EditProfile: React.FC<EditProfileProps>;
export {};
//# sourceMappingURL=EditProfile.d.ts.map