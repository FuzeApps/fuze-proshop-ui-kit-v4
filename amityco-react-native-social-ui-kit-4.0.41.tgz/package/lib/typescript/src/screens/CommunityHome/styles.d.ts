export declare const useStyles: () => {
    container: {
        backgroundColor: string;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginBottom: number;
        backgroundColor: string;
    };
    joinContainer: {
        flex: number;
        justifyContent: "center";
        alignItems: "center";
        marginVertical: number;
    };
    joinCommunityButton: {
        backgroundColor: string;
        padding: number;
        borderRadius: number;
        flexDirection: "row";
        justifyContent: "center";
        alignItems: "center";
    };
    joinCommunityText: {
        marginLeft: number;
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    dotIcon: {
        width: number;
        height: number;
    };
    imageContainer: {
        width: "100%";
        alignItems: "center";
        justifyContent: "center";
        flex: number;
    };
    image: {
        width: "100%";
        height: "100%";
    };
    imagePlaceholder: {};
    emptyImage: {
        width: "100%";
        height: "100%";
        backgroundColor: string;
    };
    darkOverlay: {
        backgroundColor: string;
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    topHeaderControls: {
        position: "absolute";
        top: number;
        bottom: number;
        left: number;
        right: number;
        paddingHorizontal: number;
        zIndex: number;
        flexDirection: "row";
        justifyContent: "space-between";
    };
    sectionWrapper: {
        paddingHorizontal: number;
        paddingTop: number;
        backgroundColor: string;
    };
    communityNameSection: {
        flexDirection: "row";
        paddingTop: number;
        paddingHorizontal: number;
        flexWrap: "nowrap";
        backgroundColor: string;
    };
    spacer: {
        width: number;
        height: number;
    };
    overlayCommunityText: {
        color: string;
        fontWeight: "bold";
        fontSize: number;
    };
    communityNameWrapper: {
        flexDirection: "row";
        justifyContent: "space-between";
    };
    communityNameWrapperLeft: {
        flexDirection: "row";
        justifyContent: "flex-start";
        flexWrap: "nowrap";
    };
    communityActions: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
    };
    communityName: {
        color: string;
        fontWeight: "bold";
        fontSize: number;
        paddingTop: number;
    };
    verifiedIconWrapper: {
        paddingTop: number;
        paddingStart: number;
    };
    shortCommunityName: {
        maxWidth: "70%";
    };
    descriptionWrapper: {
        paddingHorizontal: number;
        paddingTop: number;
    };
    description: {
        color: string;
        fontSize: number;
        fontWeight: "normal" | "bold" | "100" | "200" | "300" | "400" | "500" | "600" | "700" | "800" | "900";
        lineHeight: number;
    };
    joinIcon: {
        width: number;
        height: number;
        color: string;
    };
    overlayCategoryText: {
        color: string;
        fontWeight: "400";
        fontSize: number;
    };
    row: {
        flexDirection: "row";
        justifyContent: "flex-start";
        height: number;
        marginVertical: number;
        paddingHorizontal: number;
    };
    rowItem: {
        alignItems: "flex-start";
        justifyContent: "flex-start";
    };
    rowItemContent: {
        flexDirection: "row";
        paddingLeft: number;
    };
    verticalLine: {
        height: number;
        width: number;
        backgroundColor: string;
        marginHorizontal: number;
    };
    rowNumber: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    rowLabel: {
        fontSize: number;
        color: string;
    };
    textComponent: {
        fontSize: number;
        paddingVertical: number;
        paddingHorizontal: number;
        color: string;
    };
    pendingPostArea: {
        flex: number;
        backgroundColor: string;
        paddingVertical: number;
        alignItems: "center";
        borderRadius: number;
    };
    pendingText: {
        fontSize: number;
        fontWeight: "600";
        color: string;
        marginLeft: number;
    };
    pendingDescriptionText: {
        fontSize: number;
        fontWeight: "normal" | "bold" | "100" | "200" | "300" | "400" | "500" | "600" | "700" | "800" | "900";
        lineHeight: number;
        color: string;
    };
    pendingRow: {
        flexDirection: "row";
        alignItems: "center";
    };
    editProfileButton: {
        width: "98%";
        borderWidth: number;
        borderColor: string;
        padding: number;
        borderRadius: number;
        flexDirection: "row";
        justifyContent: "center";
        alignItems: "center";
        alignSelf: "center";
        marginTop: number;
    };
    editProfileText: {
        marginLeft: number;
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    tabBackground: {
        backgroundColor: string;
        flex: number;
    };
    ctaWrapper: {
        paddingHorizontal: number;
        paddingTop: number;
    };
    button: {
        backgroundColor: string;
        paddingHorizontal: number;
        borderRadius: number;
        flexDirection: "row";
        justifyContent: "center";
        alignItems: "center";
        flex: number;
        minHeight: number;
        marginBottom: number;
    };
    semiTransparentButton: {
        backgroundColor: string;
        height: number;
        width: number;
        borderRadius: number;
        justifyContent: "center";
        alignItems: "center";
    };
    transparentButton: {
        height: number;
        width: number;
        borderRadius: number;
        justifyContent: "center";
        alignItems: "center";
    };
};
//# sourceMappingURL=styles.d.ts.map