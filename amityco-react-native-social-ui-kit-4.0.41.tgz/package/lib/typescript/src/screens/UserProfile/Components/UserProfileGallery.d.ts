import React from 'react';
import { FeedRefType } from '../../CommunityHome';
interface IUserProfileGallery {
    userId: string;
}
declare const _default: React.MemoExoticComponent<React.ForwardRefExoticComponent<IUserProfileGallery & React.RefAttributes<FeedRefType>>>;
export default _default;
//# sourceMappingURL=UserProfileGallery.d.ts.map