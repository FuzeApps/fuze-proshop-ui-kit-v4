import React from 'react';
export default function UserProfile({ route }: any): React.JSX.Element;
//# sourceMappingURL=UserProfile.d.ts.map