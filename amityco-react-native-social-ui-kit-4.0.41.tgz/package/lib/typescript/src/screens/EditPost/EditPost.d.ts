import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { FC } from 'react';
import { RootStackParamList } from '../../routes/RouteParamList';
type IEditPost = NativeStackScreenProps<RootStackParamList, 'EditPost'>;
declare const EditPost: FC<IEditPost>;
export default EditPost;
//# sourceMappingURL=EditPost.d.ts.map