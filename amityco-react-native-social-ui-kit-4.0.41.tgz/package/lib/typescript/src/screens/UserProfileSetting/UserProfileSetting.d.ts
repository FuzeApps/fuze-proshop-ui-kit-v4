import { RouteProp } from '@react-navigation/native';
import type { NativeStackNavigationProp } from '@react-navigation/native-stack';
import React from 'react';
import { RootStackParamList } from '../../routes/RouteParamList';
export default function UserProfileSetting({ navigation, route, }: {
    navigation: NativeStackNavigationProp<RootStackParamList>;
    route: RouteProp<RootStackParamList, 'UserProfileSetting'>;
}): React.JSX.Element;
//# sourceMappingURL=UserProfileSetting.d.ts.map