export declare const useStyles: () => {
    container: {
        flex: number;
        backgroundColor: string;
    };
    navBar: {
        height: number;
        backgroundColor: string;
        flexDirection: "row";
        alignItems: "center";
        paddingHorizontal: number;
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    backIcon: {
        width: number;
        height: number;
    };
    navBarTitle: {
        fontSize: number;
        fontWeight: "bold";
        marginLeft: number;
    };
    placeholder: {
        width: number;
        height: number;
    };
    rowContainer: {
        flexDirection: "row";
        alignItems: "center";
        paddingVertical: number;
        paddingHorizontal: number;
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    iconContainer: {
        width: number;
        height: number;
        borderRadius: number;
        justifyContent: "center";
        alignItems: "center";
        marginRight: number;
    };
    icon: {
        width: number;
        height: number;
    };
    unfollowIcon: {
        width: number;
        height: number;
    };
    loadingIndicator: {
        flex: number;
        justifyContent: "center";
        alignItems: "center";
        position: "absolute";
        top: number;
        bottom: number;
        left: number;
        right: number;
        zIndex: number;
    };
    groupIcon: {
        width: number;
        height: number;
    };
    arrowIcon: {
        width: number;
        height: number;
    };
    rowText: {
        flex: number;
        fontSize: number;
        color: string;
    };
    leaveChatContainer: {
        alignItems: "center";
    };
    leaveChatText: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    leaveChatLabel: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    sectionHeader: {
        marginLeft: number;
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
};
//# sourceMappingURL=styles.d.ts.map