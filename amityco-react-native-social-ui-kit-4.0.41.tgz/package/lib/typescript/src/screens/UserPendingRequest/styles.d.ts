export declare const useStyles: () => {
    container: {
        width: number;
        alignSelf: "center";
        backgroundColor: string;
        padding: number;
        paddingVertical: number;
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    header: {
        flexDirection: "row";
        marginBottom: number;
        alignItems: "center";
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginRight: number;
    };
    displayName: {
        color: string;
        fontSize: number;
        fontWeight: "600";
    };
    actionContainer: {
        flexDirection: "row";
        marginTop: number;
        alignItems: "center";
    };
    accept: {
        flex: number;
        margin: number;
        backgroundColor: string;
        borderRadius: number;
        justifyContent: "center";
        alignItems: "center";
        paddingVertical: number;
    };
    decline: {
        flex: number;
        margin: number;
        backgroundColor: string;
        borderWidth: number;
        borderColor: string;
        borderRadius: number;
        justifyContent: "center";
        alignItems: "center";
        paddingVertical: number;
    };
    acceptText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
    };
    declineText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
    };
};
//# sourceMappingURL=styles.d.ts.map