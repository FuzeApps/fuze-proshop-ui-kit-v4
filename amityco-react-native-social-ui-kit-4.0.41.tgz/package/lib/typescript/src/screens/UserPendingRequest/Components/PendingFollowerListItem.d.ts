import { FC } from 'react';
type PendingFollowerListItemType = {
    userId: string;
};
declare const PendingFollowerListItem: FC<PendingFollowerListItemType>;
export default PendingFollowerListItem;
//# sourceMappingURL=PendingFollowerListItem.d.ts.map