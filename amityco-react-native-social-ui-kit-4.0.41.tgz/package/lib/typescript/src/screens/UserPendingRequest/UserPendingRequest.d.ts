import React from 'react';
declare const UserPendingRequest: () => React.JSX.Element;
export default UserPendingRequest;
//# sourceMappingURL=UserPendingRequest.d.ts.map