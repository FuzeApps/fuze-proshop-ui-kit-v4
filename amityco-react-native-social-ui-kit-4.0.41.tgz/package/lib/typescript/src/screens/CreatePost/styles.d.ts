export declare const useStyles: () => {
    barContainer: {
        backgroundColor: string;
    };
    header: {
        zIndex: number;
        padding: number;
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
    };
    closeButton: {
        padding: number;
        zIndex: number;
        left: number;
    };
    headerTextContainer: {
        flex: number;
        alignItems: "center";
        justifyContent: "center";
    };
    headerText: {
        fontWeight: "600";
        fontSize: number;
        textAlign: "center";
        color: string;
    };
    postText: {
        fontWeight: "400";
        fontSize: number;
        textAlign: "center";
        color: string;
    };
    rowContainer: {
        flexDirection: "row";
        alignItems: "center";
        paddingVertical: number;
        paddingHorizontal: number;
    };
    textInput: {
        borderWidth: number;
        borderBottomWidth: number;
        backgroundColor: string;
        fontSize: number;
        marginHorizontal: number;
        zIndex: number;
        paddingVertical: number;
        color: string;
        height: number;
    };
    transparentText: {
        color: string;
    };
    inputContainer: {
        flex: number;
        justifyContent: "center";
        alignItems: "flex-start";
    };
    mentionText: {
        color: string;
        fontSize: number;
    };
    inputText: {
        color: string;
        fontSize: number;
        letterSpacing: number;
    };
    overlay: {
        justifyContent: "center";
        alignItems: "flex-start";
        paddingHorizontal: number;
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    container: {
        padding: number;
    };
    AllInputWrap: {
        backgroundColor: string;
        flex: number;
    };
    InputWrap: {
        backgroundColor: string;
        width: "100%";
        flexDirection: "row";
        justifyContent: "space-around";
        paddingHorizontal: number;
        paddingBottom: number;
        paddingTop: number;
        alignItems: "center";
        borderTopWidth: number;
        borderTopColor: string;
    };
    iconWrap: {
        backgroundColor: string;
        borderRadius: number;
        alignItems: "center";
        justifyContent: "center";
        padding: number;
        width: number;
        height: number;
    };
    imageContainer: {
        flexDirection: "row";
        marginVertical: number;
        flex: number;
    };
    disabled: {
        opacity: number;
    };
    videoContainer: {
        display: "none";
    };
};
//# sourceMappingURL=styles.d.ts.map