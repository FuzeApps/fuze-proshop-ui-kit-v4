import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { FC } from 'react';
import { RootStackParamList } from '../../routes/RouteParamList';
type ICreatePost = NativeStackScreenProps<RootStackParamList, 'CreatePost'>;
declare const CreatePost: FC<ICreatePost>;
export default CreatePost;
//# sourceMappingURL=index.d.ts.map