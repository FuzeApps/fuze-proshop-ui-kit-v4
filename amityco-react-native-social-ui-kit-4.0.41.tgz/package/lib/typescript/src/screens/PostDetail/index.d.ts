import React from 'react';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../routes/RouteParamList';
type IPostDetailPage = {
    route: RouteProp<RootStackParamList, 'PostDetail'>;
};
declare const PostDetail: ({ route }: IPostDetailPage) => React.JSX.Element;
export default PostDetail;
//# sourceMappingURL=index.d.ts.map