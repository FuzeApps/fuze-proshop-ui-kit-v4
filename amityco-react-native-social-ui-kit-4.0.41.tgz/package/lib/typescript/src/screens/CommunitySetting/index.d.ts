import React from 'react';
interface ChatDetailProps {
    navigation: any;
    route: any;
}
export declare enum SettingType {
    basicInfo = "basic_info",
    leaveOrClose = "leave_or_close"
}
export declare const CommunitySetting: React.FC<ChatDetailProps>;
export {};
//# sourceMappingURL=index.d.ts.map