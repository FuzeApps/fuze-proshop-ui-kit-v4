export declare const useStyles: () => {
    container: {
        flex: number;
        backgroundColor: string;
    };
    navBar: {
        height: number;
        backgroundColor: string;
        flexDirection: "row";
        alignItems: "center";
        paddingHorizontal: number;
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    backIcon: {
        width: number;
        height: number;
    };
    navBarTitle: {
        fontSize: number;
        fontWeight: "bold";
        marginLeft: number;
    };
    placeholder: {
        width: number;
        height: number;
    };
    rowContainer: {
        flexDirection: "row";
        alignItems: "center";
        paddingVertical: number;
        paddingHorizontal: number;
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    iconContainer: {
        width: number;
        height: number;
        borderRadius: number;
        justifyContent: "center";
        alignItems: "center";
        marginRight: number;
    };
    icon: {
        width: number;
        height: number;
    };
    groupIcon: {
        width: number;
        height: number;
    };
    arrowIcon: {
        width: number;
        height: number;
    };
    rowText: {
        flex: number;
        fontSize: number;
        color: string;
    };
    leaveChatContainer: {
        alignItems: "center";
    };
    leaveChatText: {
        fontSize: number;
        color: string;
    };
    leaveChatLabel: {
        fontSize: number;
        color: string;
    };
    header: {
        fontWeight: "600";
        fontSize: number;
        marginLeft: number;
        color: string;
    };
};
//# sourceMappingURL=styles.d.ts.map