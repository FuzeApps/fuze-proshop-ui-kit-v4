import React from 'react';
export default function PreloadCommunityHome(): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map