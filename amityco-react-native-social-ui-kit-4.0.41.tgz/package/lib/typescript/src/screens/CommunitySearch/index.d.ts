import React from 'react';
export default function CommunitySearch(): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map