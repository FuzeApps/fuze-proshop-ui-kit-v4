import type { MyMD3Theme } from '../../providers/amity-ui-kit-provider';
export declare const useStyles: (theme: MyMD3Theme) => {
    container: {
        flex: number;
        backgroundColor: string;
    };
    header: {
        top: number;
        width: "100%";
        position: "absolute";
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
        padding: number;
        backgroundColor: string;
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    headerIcon: {
        width: number;
        height: number;
        tintColor: string;
        resizeMode: "contain";
    };
    headerTitle: {
        fontSize: number;
        color: string;
        fontWeight: "600";
    };
    scrollContainer: {
        flex: number;
    };
    input: {
        backgroundColor: string;
        borderRadius: number;
        fontWeight: "400";
        width: "90%";
        paddingHorizontal: number;
        paddingVertical: number;
        color: string;
    };
    AllInputWrap: {
        backgroundColor: string;
        flex: number;
        marginTop: number;
    };
    InputWrap: {
        backgroundColor: string;
        width: "100%";
        flexDirection: "row";
        justifyContent: "space-between";
        paddingHorizontal: number;
        paddingBottom: number;
        paddingTop: number;
        alignItems: "center";
        borderTopWidth: number;
        borderTopColor: string;
    };
    myAvatar: {
        width: number;
        height: number;
        borderRadius: number;
        alignSelf: "center";
        marginRight: number;
    };
    postDisabledBtn: {
        color: string;
        fontSize: number;
    };
    postBtnText: {
        color: string;
        fontSize: number;
    };
    postBtn: {
        marginHorizontal: number;
    };
    commentItem: {
        padding: number;
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    comment: {
        fontSize: number;
    };
    commentListWrap: {
        borderTopWidth: number;
        borderTopColor: string;
    };
    textInput: {
        borderWidth: number;
        borderBottomWidth: number;
        backgroundColor: string;
        fontSize: number;
        marginHorizontal: number;
        zIndex: number;
        paddingTop: number;
        width: "100%";
        borderRadius: number;
    };
    transparentText: {
        color: string;
    };
    inputContainer: {
        flex: number;
        justifyContent: "center";
        alignItems: "flex-start";
        paddingVertical: number;
        paddingHorizontal: number;
        backgroundColor: string;
        borderRadius: number;
    };
    mentionText: {
        color: string;
        fontSize: number;
    };
    inputText: {
        color: string;
        fontSize: number;
        letterSpacing: number;
    };
    overlay: {
        justifyContent: "center";
        alignItems: "flex-start";
        paddingHorizontal: number;
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    inputTextOverlayWrap: {
        flexDirection: "row";
        backgroundColor: string;
    };
    replyLabelWrap: {
        height: number;
        backgroundColor: string;
        paddingVertical: number;
        justifyContent: "space-between";
        flexDirection: "row";
        alignItems: "center";
    };
    replyLabel: {
        color: string;
        fontSize: number;
        paddingLeft: number;
        paddingRight: number;
    };
    closeIcon: {
        marginRight: number;
    };
    userNameLabel: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    commentListFooter: {
        width: number;
        position: "absolute";
        bottom: number;
    };
    modalContainer: {
        flex: number;
        justifyContent: "flex-end";
        backgroundColor: string;
    };
    modalContent: {
        backgroundColor: string;
        borderTopLeftRadius: number;
        borderTopRightRadius: number;
        padding: number;
        minHeight: number;
    };
    twoOptions: {
        minHeight: number;
    };
    modalRow: {
        flexDirection: "row";
        alignItems: "center";
        padding: number;
        marginVertical: number;
    };
    handleBar: {
        alignSelf: "center";
        width: number;
        backgroundColor: string;
        height: number;
        marginVertical: number;
        borderRadius: number;
    };
    deleteText: {
        paddingLeft: number;
        fontWeight: "600";
        color: string;
    };
};
//# sourceMappingURL=styles.d.ts.map