import React from 'react';
type AmityPostDetailPageType = {
    postId: Amity.Post['postId'];
};
declare const _default: React.NamedExoticComponent<AmityPostDetailPageType>;
export default _default;
//# sourceMappingURL=AmityPostDetailPage.d.ts.map