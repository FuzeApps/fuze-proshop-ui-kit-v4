export declare const useStyles: () => {
    container: {
        backgroundColor: string;
    };
    recommendContainer: {
        backgroundColor: string;
        paddingVertical: number;
    };
    trendingContainer: {
        paddingHorizontal: number;
        backgroundColor: string;
        paddingVertical: number;
    };
    title: {
        fontWeight: "bold";
        fontSize: number;
        marginTop: number;
        marginBottom: number;
        color: string;
    };
    listContainer: {
        flex: number;
    };
    trendingTextContainer: {
        paddingStart: number;
        flexDirection: "row";
        alignItems: "center";
        flex: number;
    };
    card: {
        width: number;
        backgroundColor: string;
        borderRadius: number;
        marginHorizontal: number;
        marginBottom: number;
        overflow: "hidden";
        height: number;
    };
    cardBody: {
        padding: number;
    };
    recommendSubDetail: {
        fontSize: number;
        marginBottom: number;
        color: string;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
    };
    recommendedAvatar: {
        width: "100%";
        minHeight: number;
    };
    recommendedCard: {
        width: number;
        backgroundColor: string;
        borderRadius: number;
        marginRight: number;
        marginBottom: number;
        overflow: "hidden";
        height: number;
    };
    name: {
        fontWeight: "600";
        fontSize: number;
        marginBottom: number;
        color: string;
    };
    bio: {
        color: string;
        fontSize: number;
    };
    communityDescription: {
        color: string;
        fontSize: number;
    };
    itemContainer: {
        flexDirection: "row";
        alignItems: "center";
        marginBottom: number;
    };
    number: {
        fontSize: number;
        fontWeight: "600";
        marginHorizontal: number;
        color: string;
        paddingBottom: number;
    };
    memberContainer: {
        alignItems: "flex-start";
        flexDirection: "row";
        flex: number;
    };
    memberText: {
        fontSize: number;
        fontWeight: "600";
        marginRight: number;
        color: string;
        maxWidth: "80%";
    };
    memberCount: {
        fontSize: number;
        fontWeight: "400";
        color: string;
        marginRight: number;
    };
    categoriesContainer: {
        paddingTop: number;
        paddingHorizontal: number;
        paddingBottom: number;
        backgroundColor: string;
    };
    titleContainer: {
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "space-between";
        marginBottom: number;
    };
    titleText: {
        fontSize: number;
        fontWeight: "bold";
        marginBottom: number;
        color: string;
    };
    arrowIcon: {
        width: number;
        height: number;
        marginRight: number;
        tintColor: string;
    };
    rowContainer: {
        flexDirection: "row";
        justifyContent: "flex-start";
        alignItems: "center";
        width: "50%";
        paddingHorizontal: number;
        marginBottom: number;
    };
    columnText: {
        fontSize: number;
        fontWeight: "600";
        marginLeft: number;
        marginBottom: number;
        color: string;
        width: "70%";
    };
    wrapContainer: {
        flexDirection: "row";
        flexWrap: "wrap";
    };
    categoryAvatar: {
        width: number;
        height: number;
        borderRadius: number;
    };
    categoryItem: {
        flexDirection: "row";
        justifyContent: "flex-start";
        alignItems: "center";
        width: "50%";
        overflow: "hidden";
        marginBottom: number;
    };
    categoryTextWrapper: {
        paddingHorizontal: number;
        justifyContent: "center";
        alignItems: "center";
        alignContent: "center";
        flexDirection: "row";
    };
    categoryName: {
        fontSize: number;
        lineHeight: number;
        fontWeight: "600";
        color: string;
    };
    officialIconWrapper: {
        position: "absolute";
        marginLeft: number;
        bottom: number;
    };
    recommendContainerScrollView: {
        paddingHorizontal: number;
    };
    recommendedTitleContainer: {
        paddingHorizontal: number;
    };
    groupsTitleContainer: {
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "space-between";
        marginBottom: number;
    };
    viewAllText: {
        fontWeight: "bold";
        fontSize: number;
        color: string;
    };
    groupTitle: {
        fontWeight: "bold";
        fontSize: number;
        color: string;
    };
};
//# sourceMappingURL=styles.d.ts.map