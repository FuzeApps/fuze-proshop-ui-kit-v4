export declare const useStyles: () => {
    container: {
        flex: number;
        backgroundColor: string;
    };
    categoryText: {
        marginLeft: number;
        marginBottom: number;
        fontSize: number;
        color: string;
    };
    LoadingIndicator: {
        paddingVertical: number;
    };
    rowContainer: {
        flexDirection: "row";
        alignItems: "center";
        padding: number;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginBottom: number;
        backgroundColor: string;
    };
};
//# sourceMappingURL=styles.d.ts.map