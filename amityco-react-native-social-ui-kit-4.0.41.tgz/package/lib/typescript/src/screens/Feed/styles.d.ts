export declare const useStyles: () => {
    feedWrap: {
        backgroundColor: string;
        flex: number;
        height: "100%";
        minHeight: number;
    };
};
//# sourceMappingURL=styles.d.ts.map