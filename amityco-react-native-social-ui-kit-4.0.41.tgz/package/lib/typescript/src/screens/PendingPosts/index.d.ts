import React from 'react';
export default function PendingPosts(): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map