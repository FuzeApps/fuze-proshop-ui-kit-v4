export declare const useStyles: () => {
    container: {
        flex: number;
        backgroundColor: string;
    };
    LoadingIndicator: {
        paddingVertical: number;
    };
    listContentContainer: {
        paddingBottom: number;
    };
};
//# sourceMappingURL=styles.d.ts.map