import React from 'react';
export default function AllCommunitiesListing({ navigation }: any): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map