import React from 'react';
declare const CommunityItem: ({ item, onPressCommunity, }: {
    item: Amity.Community & {
        category?: string;
    };
    onPressCommunity: (community: {
        communityId: string;
        communityName: string;
    }) => void;
}) => React.JSX.Element;
export default CommunityItem;
//# sourceMappingURL=CommunityItem.d.ts.map