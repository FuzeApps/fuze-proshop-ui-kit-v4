export declare const useStyles: () => {
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginBottom: number;
        backgroundColor: string;
        justifyContent: "center";
        alignItems: "center";
    };
    rowContainer: {
        flexDirection: "row";
        alignItems: "center";
        padding: number;
    };
    communityName: {
        marginLeft: number;
        marginBottom: number;
        fontSize: number;
        fontWeight: "bold";
        color: string;
    };
    category: {
        marginVertical: number;
        alignSelf: "flex-start";
        paddingHorizontal: number;
        paddingVertical: number;
        backgroundColor: string;
        color: string;
        borderRadius: number;
        overflow: "hidden";
        marginHorizontal: number;
        fontSize: number;
    };
    textContainer: {
        flex: number;
        marginLeft: number;
    };
};
//# sourceMappingURL=communityItem.styles.d.ts.map