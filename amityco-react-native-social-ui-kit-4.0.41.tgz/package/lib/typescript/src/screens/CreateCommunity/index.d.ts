import * as React from 'react';
export default function CreateCommunity(): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map