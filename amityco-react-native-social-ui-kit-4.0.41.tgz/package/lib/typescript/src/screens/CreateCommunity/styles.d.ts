export declare const useStyles: () => {
    container: {
        paddingBottom: number;
        backgroundColor: string;
    };
    uploadContainer: {
        width: "100%";
        height: "35%";
        alignItems: "center";
        justifyContent: "center";
        backgroundColor: string;
    };
    defaultImage: {
        width: "100%";
        height: "100%";
        backgroundColor: string;
    };
    image: {
        width: "100%";
        height: "100%";
    };
    button: {
        position: "absolute";
        backgroundColor: string;
        borderColor: string;
        borderWidth: number;
        paddingVertical: number;
        paddingHorizontal: number;
        borderRadius: number;
        alignItems: "center";
        justifyContent: "center";
    };
    buttonText: {
        color: string;
        fontWeight: "bold";
    };
    btnWrap: {
        padding: number;
    };
    allInputContainer: {
        paddingVertical: number;
        backgroundColor: string;
    };
    inputContainer: {
        paddingHorizontal: number;
        justifyContent: "center";
        marginBottom: number;
    };
    inputTitle: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    requiredField: {
        color: string;
    };
    inputField: {
        borderBottomWidth: number;
        borderBottomColor: string;
        borderRadius: number;
        marginTop: number;
        paddingVertical: number;
        color: string;
    };
    inputLengthMeasure: {
        alignSelf: "flex-end";
        marginTop: number;
        color: string;
    };
    placeHolderText: {
        color: string;
    };
    titleRow: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
    };
    categoryContainer: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
        paddingVertical: number;
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    addIcon: {
        marginHorizontal: number;
    };
    arrowIcon: {
        opacity: number;
    };
    listItem: {
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "space-between";
        paddingBottom: number;
        paddingHorizontal: number;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginRight: number;
        backgroundColor: string;
        alignItems: "center";
        justifyContent: "center";
    };
    itemText: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    dotIcon: {
        width: number;
        height: number;
    };
    categoryText: {
        fontSize: number;
        color: string;
        marginTop: number;
    };
    optionDescription: {
        width: "70%";
    };
    radioGroup: {
        borderBottomWidth: number;
        borderBottomColor: string;
        marginBottom: number;
    };
    createButton: {
        flexDirection: "row";
        backgroundColor: string;
        justifyContent: "center";
        alignItems: "center";
        paddingVertical: number;
        marginHorizontal: number;
        borderRadius: number;
        marginBottom: number;
    };
    createText: {
        fontWeight: "600";
        fontSize: number;
        color: string;
    };
    addUsersContainer: {
        marginVertical: number;
        borderBottomWidth: number;
        borderBottomColor: string;
        paddingBottom: number;
    };
    userItemWrap: {
        flexDirection: "row";
        backgroundColor: string;
        borderRadius: number;
        padding: number;
        height: number;
        flex: number;
        alignItems: "center";
        justifyContent: "space-between";
        margin: number;
        maxWidth: "45%";
    };
    avatarImageContainer: {
        overflow: "hidden";
        borderRadius: number;
        width: number;
        height: number;
        marginRight: number;
    };
    avatarImage: {
        width: number;
        height: number;
    };
    avatarRow: {
        flexDirection: "row";
        alignItems: "center";
    };
    loading: {
        marginLeft: number;
    };
    disableBtn: {
        opacity: number;
    };
};
//# sourceMappingURL=styles.d.ts.map