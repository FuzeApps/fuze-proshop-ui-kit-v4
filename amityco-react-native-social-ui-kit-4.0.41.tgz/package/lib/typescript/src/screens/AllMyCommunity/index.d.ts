import React from 'react';
export default function AllMyCommunity(): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map