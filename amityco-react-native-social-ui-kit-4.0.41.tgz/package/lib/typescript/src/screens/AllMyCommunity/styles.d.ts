export declare const useStyles: () => {
    container: {
        backgroundColor: string;
        paddingBottom: number;
        height: "100%";
    };
    headerWrap: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
        backgroundColor: string;
    };
    inputWrap: {
        marginHorizontal: number;
        backgroundColor: string;
        color: string;
        paddingHorizontal: number;
        paddingVertical: number;
        borderRadius: number;
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
        marginVertical: number;
        flex: number;
    };
    input: {
        flex: number;
        marginHorizontal: number;
        backgroundColor: string;
        color: string;
    };
    cancelBtn: {
        marginRight: number;
        color: string;
    };
    searchScrollList: {
        paddingBottom: number;
        marginTop: number;
    };
    btnWrap: {
        padding: number;
        marginHorizontal: number;
    };
};
//# sourceMappingURL=styles.d.ts.map