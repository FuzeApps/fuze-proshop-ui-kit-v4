import { ImageProps } from 'react-native';
import React from 'react';
import { ComponentID, PageID } from '../../enum';
type LikeButtonIconElementType = Partial<ImageProps> & {
    pageID?: PageID;
    componentID?: ComponentID;
};
declare const _default: React.NamedExoticComponent<LikeButtonIconElementType>;
export default _default;
//# sourceMappingURL=LikeButtonIconElement.d.ts.map