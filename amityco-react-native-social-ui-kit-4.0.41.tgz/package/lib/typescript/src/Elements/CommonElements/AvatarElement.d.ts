import { FC } from 'react';
import { ImageProps } from 'react-native';
import { ComponentID, ElementID, PageID } from '../../enum';
type AvatarElementType = Partial<ImageProps> & {
    avatarId: string;
    pageID?: PageID;
    componentID?: ComponentID;
    elementID: ElementID;
    targetType?: 'community' | 'user';
};
declare const AvatarElement: FC<AvatarElementType>;
export default AvatarElement;
//# sourceMappingURL=AvatarElement.d.ts.map