import { TextProps } from 'react-native';
import React from 'react';
import { ComponentID, ElementID, PageID } from '../../enum';
type CategoryElementType = Partial<TextProps> & {
    pageID: PageID;
    componentID: ComponentID;
    elementID: ElementID;
    categoryId: Amity.Category['categoryId'];
};
declare const _default: React.NamedExoticComponent<CategoryElementType>;
export default _default;
//# sourceMappingURL=CategoryElement.d.ts.map