import { TextProps } from 'react-native';
import React from 'react';
import { ComponentID, ElementID, PageID } from '../../enum';
type TextElementType = Partial<TextProps> & {
    pageID: PageID;
    componentID: ComponentID;
    elementID: ElementID;
    text: string;
};
declare const _default: React.NamedExoticComponent<TextElementType>;
export default _default;
//# sourceMappingURL=TextElement.d.ts.map