import { TextProps } from 'react-native';
import React from 'react';
import { ComponentID, PageID } from '../../enum';
type TimeStampElementType = Partial<TextProps> & {
    pageID?: PageID;
    componentID?: ComponentID;
    createdAt: string;
};
declare const _default: React.NamedExoticComponent<TimeStampElementType>;
export default _default;
//# sourceMappingURL=TimestampElement.d.ts.map