import { ImageProps } from 'react-native';
import React from 'react';
import { ComponentID, PageID } from '../../enum';
type MenuButtonIconElementType = Partial<ImageProps> & {
    pageID?: PageID;
    componentID?: ComponentID;
};
declare const _default: React.NamedExoticComponent<MenuButtonIconElementType>;
export default _default;
//# sourceMappingURL=MenuButtonIconElement.d.ts.map