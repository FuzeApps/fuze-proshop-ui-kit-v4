import { ImageProps } from 'react-native';
import React from 'react';
import { ComponentID, PageID } from '../../enum/enumUIKitID';
type BackButtonIconElementType = Partial<ImageProps> & {
    pageID?: PageID;
    componentID?: ComponentID;
};
declare const _default: React.NamedExoticComponent<BackButtonIconElementType>;
export default _default;
//# sourceMappingURL=BackButtonIconElement.d.ts.map