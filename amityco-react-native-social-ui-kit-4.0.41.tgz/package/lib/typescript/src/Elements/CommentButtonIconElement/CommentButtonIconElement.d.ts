import { ImageProps } from 'react-native';
import React from 'react';
import { ComponentID, PageID } from '../../enum';
type CommentButtonIconElementType = Partial<ImageProps> & {
    pageID?: PageID;
    componentID?: ComponentID;
};
declare const _default: React.NamedExoticComponent<CommentButtonIconElementType>;
export default _default;
//# sourceMappingURL=CommentButtonIconElement.d.ts.map