import type { MyMD3Theme } from '../../providers/amity-ui-kit-provider';
export declare const useStyles: (theme: MyMD3Theme) => {
    moderatorTitle: {
        fontSize: number;
        color: string;
    };
    moderatorRow: {
        alignSelf: "flex-start";
        flexDirection: "row";
        padding: number;
        paddingHorizontal: number;
        backgroundColor: string;
        borderRadius: number;
        alignItems: "center";
        justifyContent: "center";
    };
    moderatorBadge: {
        marginRight: number;
    };
};
//# sourceMappingURL=styles.d.ts.map