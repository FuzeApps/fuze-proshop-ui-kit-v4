import { TextProps } from 'react-native';
import React from 'react';
import { ComponentID, PageID } from '../../enum';
type ModeratorBadgeElementType = Partial<TextProps> & {
    pageID: PageID;
    componentID: ComponentID;
    communityId?: Amity.Community['communityId'];
    userId?: Amity.User['userId'];
};
declare const _default: React.NamedExoticComponent<ModeratorBadgeElementType>;
export default _default;
//# sourceMappingURL=ModeratorBadgeElement.d.ts.map