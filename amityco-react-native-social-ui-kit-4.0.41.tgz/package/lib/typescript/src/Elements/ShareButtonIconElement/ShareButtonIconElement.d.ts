import { ImageProps } from 'react-native';
import React from 'react';
import { ComponentID, PageID } from '../../enum';
type ShareButtonIconElementType = Partial<ImageProps> & {
    pageID?: PageID;
    componentID?: ComponentID;
};
declare const _default: React.NamedExoticComponent<ShareButtonIconElementType>;
export default _default;
//# sourceMappingURL=ShareButtonIconElement.d.ts.map