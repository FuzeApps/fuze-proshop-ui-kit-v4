import { TextProps } from 'react-native';
import React from 'react';
import { ComponentID, ElementID, PageID } from '../../enum/enumUIKitID';
type TextElementType = Partial<TextProps> & {
    pageID: PageID;
    componentID: ComponentID;
    elementID: ElementID;
};
declare const _default: React.NamedExoticComponent<TextElementType>;
export default _default;
//# sourceMappingURL=TextKeyElement.d.ts.map