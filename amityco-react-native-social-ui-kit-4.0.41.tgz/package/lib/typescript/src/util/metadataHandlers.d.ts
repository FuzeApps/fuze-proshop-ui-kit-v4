/**
 * Given a community ID, remove the community ID to the user's joinedCommunities metadata.
 */
export declare const removeFromJoinedCommunities: (userId: string, communityId: string) => Promise<void>;
/**
 * Given a community ID, set the user's created community ID.
 */
export declare const setCreatedCommunityId: (userId: string, communityId: string) => Promise<void>;
/**
 * Given a community ID, remove the created community Id to user's metadata.
 */
export declare const deleteCreatedCommunityId: (userId: string, communityId: string) => Promise<void>;
export declare const metadataHandlers: {
    addToJoinedCommunities: (userId: string, communityId: string) => Promise<void>;
    removeFromJoinedCommunities: (userId: string, communityId: string) => Promise<void>;
    setCreatedCommunityId: (userId: string, communityId: string) => Promise<void>;
    deleteCreatedCommunityId: (userId: string, communityId: string) => Promise<void>;
};
export default metadataHandlers;
//# sourceMappingURL=metadataHandlers.d.ts.map