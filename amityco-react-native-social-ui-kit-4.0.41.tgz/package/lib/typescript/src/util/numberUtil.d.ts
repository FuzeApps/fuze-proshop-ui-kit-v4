export declare const formatNumber: (num: number) => string;
//# sourceMappingURL=numberUtil.d.ts.map