export declare const useKeyboardStatus: () => {
    isKeyboardShowing: boolean;
    keyboardHeight: number;
};
//# sourceMappingURL=useKeyboardStatus.d.ts.map