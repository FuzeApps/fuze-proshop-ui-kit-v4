import { IPost } from '../components/AmityPostContentComponent/AmityPostContentComponent';
export declare const usePostImpression: (postList: IPost[]) => {
    handleViewChange: ({ viewableItems }: {
        viewableItems: any;
    }) => void;
};
//# sourceMappingURL=usePostImpression.d.ts.map