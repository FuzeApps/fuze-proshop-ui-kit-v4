export declare const useCommunities: () => {
    communities: Amity.Community[];
    onNextCommunityPage: () => void | null;
};
//# sourceMappingURL=useCommunities.d.ts.map