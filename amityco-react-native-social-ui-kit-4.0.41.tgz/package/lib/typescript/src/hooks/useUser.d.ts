export declare const useUser: (userId: string) => Amity.User;
//# sourceMappingURL=useUser.d.ts.map