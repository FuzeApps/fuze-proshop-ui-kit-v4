import { TabName } from '../enum';
export declare const useAmityGlobalSearchViewModel: (searchValue: string, searchType: TabName) => {
    searchResult: any;
    onNextCommunityPage: () => void;
    onNextUserPage: () => void;
    isLoading: boolean;
};
//# sourceMappingURL=useAmityGlobalSearchViewModel.d.ts.map