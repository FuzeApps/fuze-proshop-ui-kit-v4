export declare const useDarkMode: () => {
    isDarkTheme: boolean;
};
//# sourceMappingURL=useDarkMode.d.ts.map