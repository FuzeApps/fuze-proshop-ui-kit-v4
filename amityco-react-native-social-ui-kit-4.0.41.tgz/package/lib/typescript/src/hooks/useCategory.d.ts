export declare const useCategory: () => {
    getCategory: (categoryId: Amity.Category['categoryId']) => Promise<Amity.Category>;
};
//# sourceMappingURL=useCategory.d.ts.map