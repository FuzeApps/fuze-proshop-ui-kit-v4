export declare const useGenerateShades: () => (hexColor?: string) => string[];
//# sourceMappingURL=useGenerateShades.d.ts.map