export declare const useAuthStatic: () => import("..").IAmityUIkitProvider;
//# sourceMappingURL=useAuthStatic.d.ts.map