import { ImageSourcePropType } from 'react-native';
import { IUIKitConfigOptions } from '../types/config.interface';
import { UiKitConfigKeys } from '../enum';
export declare const useConfigImageUri: ({ configPath, configKey, }: {
    configPath: IUIKitConfigOptions;
    configKey: keyof UiKitConfigKeys;
}) => ImageSourcePropType;
//# sourceMappingURL=useConfigImageUri.d.ts.map