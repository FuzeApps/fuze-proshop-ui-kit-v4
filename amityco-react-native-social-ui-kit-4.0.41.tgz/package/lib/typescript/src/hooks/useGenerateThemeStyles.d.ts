import { MyMD3Theme } from '../providers/amity-ui-kit-provider';
import { IConfigRaw } from '../types/config.interface';
export declare const mergeTheme: (obj1: any, obj2: Object) => any;
export declare const useGenerateThemeStyles: (config: IConfigRaw) => MyMD3Theme;
//# sourceMappingURL=useGenerateThemeStyles.d.ts.map