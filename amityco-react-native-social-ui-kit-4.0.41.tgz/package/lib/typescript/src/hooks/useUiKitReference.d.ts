import { ComponentID, ElementID, PageID } from '../enum';
export declare const useAmityElement: ({ pageId, componentId, elementId, }: {
    pageId: PageID;
    componentId: ComponentID;
    elementId: ElementID;
}) => {
    config: Record<string, string | string[] | Record<string, string>>;
    defaultConfig: any;
    uiReference: string;
    accessibilityId: string;
    themeStyles: import("../providers/amity-ui-kit-provider").MyMD3Theme;
    isExcluded: boolean;
};
export declare const useAmityComponent: ({ pageId, componentId, }: {
    pageId: PageID;
    componentId: ComponentID;
}) => {
    config: Record<string, string | string[] | Record<string, string>>;
    defaultConfig: any;
    uiReference: string;
    accessibilityId: string;
    themeStyles: import("../providers/amity-ui-kit-provider").MyMD3Theme;
    isExcluded: boolean;
};
export declare const useAmityPage: ({ pageId }: {
    pageId: PageID;
}) => {
    config: Record<string, string | string[] | Record<string, string>>;
    defaultConfig: any;
    uiReference: string;
    accessibilityId: string;
    themeStyles: import("../providers/amity-ui-kit-provider").MyMD3Theme;
    isExcluded: boolean;
};
//# sourceMappingURL=useUiKitReference.d.ts.map