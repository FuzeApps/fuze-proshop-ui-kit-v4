export declare const useCommunity: (communityId: Amity.Community['communityId']) => {
    community: Amity.Community;
};
//# sourceMappingURL=useCommunity.d.ts.map