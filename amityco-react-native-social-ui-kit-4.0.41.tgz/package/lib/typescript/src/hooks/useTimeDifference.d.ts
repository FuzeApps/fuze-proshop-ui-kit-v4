export declare const useTimeDifference: (timestamp: string) => string;
//# sourceMappingURL=useTimeDifference.d.ts.map