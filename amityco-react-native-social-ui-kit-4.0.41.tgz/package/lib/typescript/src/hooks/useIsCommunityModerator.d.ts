export declare const useIsCommunityModerator: ({ userId, communityId, }: {
    userId: string;
    communityId: string;
}) => {
    isCommunityModerator: boolean;
};
//# sourceMappingURL=useIsCommunityModerator.d.ts.map