import { ImageSizeSubset } from '../enum/imageSizeState';
interface useFileProps {
    fileId: string;
    imageSize?: ImageSizeSubset;
}
export declare const useFileV4: () => {
    getImage: ({ fileId, imageSize }: useFileProps) => Promise<any>;
};
export {};
//# sourceMappingURL=useFilev4.d.ts.map