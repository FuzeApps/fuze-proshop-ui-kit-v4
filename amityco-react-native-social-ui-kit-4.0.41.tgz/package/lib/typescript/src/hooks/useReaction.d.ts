export declare const useReaction: ({ referenceId, referenceType, }: {
    referenceId: string;
    referenceType: Amity.ReactableType;
}) => {
    loading: boolean;
    allReactionList: Amity.Reactor[];
    likeReactionList: Amity.Reactor[];
    loveReactionList: Amity.Reactor[];
    hasError: any;
};
//# sourceMappingURL=useReaction.d.ts.map