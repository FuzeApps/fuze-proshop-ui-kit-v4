import { UiKitConfigKeys } from '../enum/enumUIKitID';
import { IUIKitConfigOptions } from '../types/config.interface';
type UIKitConfigT = IUIKitConfigOptions & {
    keys: (keyof UiKitConfigKeys)[];
};
export declare const useUiKitConfig: ({ keys, ...rest }: UIKitConfigT) => (string | string[] | Record<string, string>)[];
export {};
//# sourceMappingURL=useUiKitConfig.d.ts.map