import { IUIKitConfigOptions } from '../types/config.interface';
interface IUIKitConfig {
    preferred_theme: 'light' | 'dark' | 'default';
    globalTheme: Record<string, any>;
    excludes: string[];
    getConfig: (key: string) => any;
    getDefaultConfig: (key: string) => any;
    getUiKitConfig: (arg: IUIKitConfigOptions) => Record<string, string | string[] | Record<string, string>> | null;
}
declare const useConfig: () => IUIKitConfig;
export default useConfig;
//# sourceMappingURL=useConfig.d.ts.map