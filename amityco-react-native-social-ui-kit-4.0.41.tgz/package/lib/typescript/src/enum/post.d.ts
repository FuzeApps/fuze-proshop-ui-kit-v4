export declare const enum AmityPostTargetSelectionPageType {
    post = "post",
    poll = "poll",
    livestream = "livestream",
    story = "story"
}
//# sourceMappingURL=post.d.ts.map