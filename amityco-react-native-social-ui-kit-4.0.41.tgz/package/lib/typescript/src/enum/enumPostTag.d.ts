export declare enum PostTag {
    Feed = "Feed",
    Activity = "Activity",
    Leaderboard = "Leaderboard"
}
//# sourceMappingURL=enumPostTag.d.ts.map