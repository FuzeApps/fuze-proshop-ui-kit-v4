export declare enum UserRole {
    PRO = "pro",
    USER = "user",
    ADMIN = "admin"
}
//# sourceMappingURL=userRole.d.ts.map