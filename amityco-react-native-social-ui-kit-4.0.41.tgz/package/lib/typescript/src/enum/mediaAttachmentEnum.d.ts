export declare enum mediaAttachment {
    image = "image",
    video = "video",
    file = "file"
}
//# sourceMappingURL=mediaAttachmentEnum.d.ts.map