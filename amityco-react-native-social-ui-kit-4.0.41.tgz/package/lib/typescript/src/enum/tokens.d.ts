import { CustomColors } from '../providers/amity-ui-kit-provider';
export declare const amityUIKitTokens: {
    spacing: {
        /**
         * 2 pixels spacing
         */
        xxs1: number;
        /**
         * 4 pixels spacing
         */
        xxs2: number;
        /**
         * 8 pixels spacing
         */
        s1: number;
        /**
         * 12 pixels spacing
         */
        s2: number;
        /**
         * 16 pixels spacing
         */
        m1: number;
        /**
         * 20 pixels spacing
         */
        m2: number;
        /**
         * 24 pixels spacing
         */
        m3: number;
        /**
         * 32 pixels spacing
         */
        l1: number;
        /**
         * 40 pixels spacing
         */
        l2: number;
        /**
         * 48 pixels spacing
         */
        l3: number;
        /**
         * 56 pixels spacing
         */
        l4: number;
        /**
         * 64 pixels spacing
         */
        xl1: number;
        /**
         * 72 pixels spacing
         */
        xl2: number;
        /**
         * 96 pixels spacing
         */
        xl3: number;
    };
    borderRadius: {
        small: number;
        medium: number;
        large: number;
    };
    colors: CustomColors;
    fontSize: {
        /**
         * 12 pixels font size
         */
        caption1: number;
        /**
         * 13 pixels font size
         */
        footnote: number;
        /**
         * 15 pixels font size
         */
        subheadline: number;
        /**
         * 28 pixels font size
         */
        title1: number;
        /**
         * 34 pixels font size
         */
        largeTitle: number;
        /**
         * 17 pixels font size
         */
        body: number;
        /**
         * 20 pixels font size
         */
        title3: number;
        /**
         * 11 pixels font size
         */
        caption2: number;
        /**
         * 17 pixels font size
         */
        headline: number;
        /**
         * 22 pixels font size
         */
        title2: number;
        /**
         * 16 pixels font size
         */
        callout: number;
        /**
         * 8 pixels font size
         */
        caption3: number;
    };
    fontWeight: Record<string, FontWeight>;
    lineHeight: {
        /**
         * 16 line height
         */
        caption1: number;
        /**
         * 18 line height
         */
        footnote: number;
        /**
         * 20 line height
         */
        subheadline: number;
        /**
         * 34 line height
         */
        title1: number;
        /**
         * 41 line height
         */
        largeTitle: number;
        /**
         * 22 line height
         */
        body: number;
        /**
         * 25 line height
         */
        title3: number;
        /**
         * 13 line height
         */
        caption2: number;
        /**
         * 22 line height
         */
        headline: number;
        /**
         * 28 line height
         */
        title2: number;
        /**
         * 21 line height
         */
        callout: number;
        /**
         * 13 line height
         */
        caption3: number;
    };
};
type FontWeight = 'normal' | 'bold' | '100' | '200' | '300' | '400' | '500' | '600' | '700' | '800' | '900';
export {};
//# sourceMappingURL=tokens.d.ts.map