/**
 * Enum for Amity User Metadata Keys
 * Use this for consistency.
 */
export declare enum AmityUserMetadataKeys {
    ProShopRole = "proShopRole",
    HasInitiallyJoined19thHole = "hasInitiallyJoined19thHole",
    HasSyncedUserAvatar = "hasSyncedUserAvatar",
    OwnedCommunities = "ownedCommunities",
    JoinedCommunities = "joinedCommunities",
    CreatedCommunityId = "createdCommunityId"
}
//# sourceMappingURL=AmityUserMetadataKeys.d.ts.map