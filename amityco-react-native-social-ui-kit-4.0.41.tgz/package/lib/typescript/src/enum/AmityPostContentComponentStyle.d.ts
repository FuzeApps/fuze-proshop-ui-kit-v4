export declare enum AmityPostContentComponentStyleEnum {
    feed = "feed",
    detail = "detail"
}
//# sourceMappingURL=AmityPostContentComponentStyle.d.ts.map