/**
 * Enum for Amity UI Kit Routes
 */
export declare enum AmityUiKitRoutes {
    Explore = "Explore",
    MyCommunity = "MyCommunity",
    Newsfeed = "Newsfeed",
    UserProfile = "UserProfile",
    PreloadCommunityHome = "PreloadCommunityHome",
    MyUserProfile = "MyUserProfile",
    Home = "Home",
    Community = "Community",
    PostDetail = "PostDetail",
    CategoryList = "CategoryList",
    CommunityHome = "CommunityHome",
    PendingPosts = "PendingPosts",
    CommunitySearch = "CommunitySearch",
    CommunityMemberDetail = "CommunityMemberDetail",
    CommunitySetting = "CommunitySetting",
    CreateCommunity = "CreateCommunity",
    CommunityList = "CommunityList",
    AmitySocialGlobalSearchPage = "AmitySocialGlobalSearchPage",
    CreatePost = "CreatePost",
    CreatePoll = "CreatePoll",
    EditProfile = "EditProfile",
    EditCommunity = "EditCommunity",
    UserProfileSetting = "UserProfileSetting",
    EditPost = "EditPost",
    FollowerList = "FollowerList",
    UserPendingRequest = "UserPendingRequest",
    AllCommunitiesListing = "AllCommunitiesListing"
}
//# sourceMappingURL=AmityUiKitRoutes.d.ts.map