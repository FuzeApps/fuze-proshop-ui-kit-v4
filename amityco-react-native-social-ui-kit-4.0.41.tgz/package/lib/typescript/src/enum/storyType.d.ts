export declare enum StoryType {
    image = "image",
    video = "video"
}
//# sourceMappingURL=storyType.d.ts.map