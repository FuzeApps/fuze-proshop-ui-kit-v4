import React from 'react';
import AmityUiKitProvider, { IAmityUIkitProvider } from './providers/amity-ui-kit-provider';
import AmityUiKitSocial from './routes/SocialNavigator';
import { PostTag } from './enum/enumPostTag';
import { AmityUiKitRoutes, AmityUserMetadataKeys } from './enum';
declare const ExploreScreen: () => React.JSX.Element;
declare const MyCommunityScreen: () => React.JSX.Element;
declare const NewsfeedScreen: () => React.JSX.Element;
declare const UserProfileScreen: () => React.JSX.Element;
declare const PreloadCommunityHomeScreen: () => React.JSX.Element;
declare const MyUserProfileScreen: () => React.JSX.Element;
export { AmityUiKitProvider, AmityUiKitSocial, ExploreScreen, MyCommunityScreen, NewsfeedScreen, UserProfileScreen, PreloadCommunityHomeScreen, MyUserProfileScreen, PostTag, AmityUiKitRoutes, AmityUserMetadataKeys, IAmityUIkitProvider, };
//# sourceMappingURL=index.d.ts.map