import { PayloadAction } from '@reduxjs/toolkit';
import { PostTargetType } from '../../enum/postTargetType';
interface UIState {
    showPostTypeChoiceModal: boolean;
    userId: string | null;
    targetId?: string | null;
    targetType?: PostTargetType | '';
    targetName?: string;
    isPublic?: boolean;
    postSetting?: ValueOf<Readonly<{
        ONLY_ADMIN_CAN_POST: 'ONLY_ADMIN_CAN_POST';
        ADMIN_REVIEW_POST_REQUIRED: 'ADMIN_REVIEW_POST_REQUIRED';
        ANYONE_CAN_POST: 'ANYONE_CAN_POST';
    }>>;
    needApprovalOnPostCreation?: boolean;
    showToastMessage?: boolean;
    toastMessage?: string;
    isLoadingToast?: boolean;
    isSuccessToast?: boolean;
}
declare const uiSlice: import("@reduxjs/toolkit").Slice<UIState, {
    openPostTypeChoiceModal: (state: import("immer/dist/internal").WritableDraft<UIState>, action: PayloadAction<{
        userId: string;
        targetId?: string;
        targetName?: string;
        targetType?: PostTargetType;
        isPublic?: boolean;
        postSetting?: ValueOf<Readonly<{
            ONLY_ADMIN_CAN_POST: 'ONLY_ADMIN_CAN_POST';
            ADMIN_REVIEW_POST_REQUIRED: 'ADMIN_REVIEW_POST_REQUIRED';
            ANYONE_CAN_POST: 'ANYONE_CAN_POST';
        }>>;
        needApprovalOnPostCreation?: boolean;
    }>) => void;
    closePostTypeChoiceModal: (state: import("immer/dist/internal").WritableDraft<UIState>) => void;
    showToastMessage: (state: import("immer/dist/internal").WritableDraft<UIState>, action: PayloadAction<{
        toastMessage: string;
        isLoadingToast?: boolean;
        isSuccessToast?: boolean;
    }>) => void;
    hideToastMessage: (state: import("immer/dist/internal").WritableDraft<UIState>) => void;
}, "ui">;
export default uiSlice;
//# sourceMappingURL=uiSlice.d.ts.map