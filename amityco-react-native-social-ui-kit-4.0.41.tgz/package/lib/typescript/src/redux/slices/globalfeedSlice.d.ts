import { PayloadAction } from '@reduxjs/toolkit';
import { IPost } from '../../components/Social/PostList';
interface GlobalFeedState {
    postList: IPost[];
}
declare const globalFeedSlice: import("@reduxjs/toolkit").Slice<GlobalFeedState, {
    updateGlobalFeed: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>, action: PayloadAction<IPost[]>) => void;
    addPostToGlobalFeed: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>, action: PayloadAction<IPost>) => void;
    updateByPostId: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>, action: PayloadAction<{
        postId: string;
        postDetail: IPost;
    }>) => void;
    deleteByPostId: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>, action: PayloadAction<{
        postId: string;
    }>) => void;
    clearFeed: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>) => void;
}, "globalFeed">;
export default globalFeedSlice;
//# sourceMappingURL=globalfeedSlice.d.ts.map