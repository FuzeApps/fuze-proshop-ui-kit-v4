import { PayloadAction } from '@reduxjs/toolkit';
import { IPost } from '../../components/Social/PostList';
interface PostDetailState {
    currentIndex: number;
    currentPostdetail: IPost | {};
}
declare const postDetailSlice: import("@reduxjs/toolkit").Slice<PostDetailState, {
    updateCurrentIndex: (state: import("immer/dist/internal").WritableDraft<PostDetailState>, action: PayloadAction<number>) => void;
    updatePostDetail: (state: import("immer/dist/internal").WritableDraft<PostDetailState>, action: PayloadAction<IPost>) => void;
}, "postDetail">;
export default postDetailSlice;
//# sourceMappingURL=postDetailSlice.d.ts.map