import { PayloadAction } from '@reduxjs/toolkit';
import { IPost } from '../../components/Social/PostList';
interface FeedState {
    postList: IPost[];
}
declare const feedSlice: import("@reduxjs/toolkit").Slice<FeedState, {
    updateFeed: (state: import("immer/dist/internal").WritableDraft<FeedState>, action: PayloadAction<IPost[]>) => void;
    addPostToFeed: (state: import("immer/dist/internal").WritableDraft<FeedState>, action: PayloadAction<IPost>) => void;
    updateByPostId: (state: import("immer/dist/internal").WritableDraft<FeedState>, action: PayloadAction<{
        postId: string;
        postDetail: IPost;
    }>) => void;
    deleteByPostId: (state: import("immer/dist/internal").WritableDraft<FeedState>, action: PayloadAction<{
        postId: string;
    }>) => void;
    clearFeed: (state: import("immer/dist/internal").WritableDraft<FeedState>) => void;
}, "feed">;
export default feedSlice;
//# sourceMappingURL=feedSlice.d.ts.map