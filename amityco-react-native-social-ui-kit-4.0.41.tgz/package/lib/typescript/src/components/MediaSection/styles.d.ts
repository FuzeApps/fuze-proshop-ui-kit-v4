import { StyleSheet } from 'react-native';
export declare const useStyles: () => StyleSheet.NamedStyles<any> | StyleSheet.NamedStyles<{
    imageLargePost: {
        height: number;
        borderRadius: number;
        resizeMode: "cover";
    };
    imageMediumLargePost: {
        height: number;
        borderRadius: number;
    };
    imageMediumPost: {
        height: number;
        borderRadius: number;
    };
    imageSmallPost: {
        height: number;
        borderRadius: number;
    };
    imageMarginRight: {
        marginRight: number;
    };
    imageMarginLeft: {
        marginLeft: number;
    };
    imageMarginTop: {
        marginTop: number;
    };
    imageMarginBottom: {
        marginBottom: number;
    };
    imagesWrap: {
        display: "flex";
        flex: number;
        marginTop: number;
        marginBottom: number;
        width: "100%";
    };
    row: {
        flexDirection: "row";
    };
    col2: {
        flex: number;
    };
    col3: {
        flex: number;
    };
    col6: {
        flex: number;
    };
    overlay: {
        backgroundColor: string;
        justifyContent: "center";
        alignItems: "center";
        borderRadius: number;
        marginTop: number;
        marginLeft: number;
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    overlayText: {
        color: string;
        fontSize: number;
        fontWeight: "bold";
    };
    playButton: {
        width: number;
        height: number;
        borderRadius: number;
        position: "absolute";
        top: "50%";
        left: "50%";
        transform: ({
            translateX: number;
            translateY?: undefined;
        } | {
            translateY: number;
            translateX?: undefined;
        })[];
        zIndex: number;
    };
}>;
//# sourceMappingURL=styles.d.ts.map