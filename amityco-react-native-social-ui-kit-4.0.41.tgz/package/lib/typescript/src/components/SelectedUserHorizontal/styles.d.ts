export declare const useStyles: () => {
    container: {
        flexGrow: number;
        paddingLeft: number;
        paddingTop: number;
        paddingBottom: number;
        alignItems: "center";
        backgroundColor: string;
    };
    avatarContainer: {
        marginRight: number;
        alignItems: "center";
    };
    avatar: {
        position: "relative";
        width: number;
        height: number;
    };
    avatarImageContainer: {
        overflow: "hidden";
        borderRadius: number;
        width: number;
        height: number;
    };
    avatarImage: {
        width: number;
        height: number;
    };
    deleteButton: {
        backgroundColor: string;
        borderRadius: number;
        width: number;
        height: number;
        position: "absolute";
        top: number;
        right: number;
        alignItems: "center";
        justifyContent: "center";
    };
    deleteButtonText: {
        color: string;
        fontSize: number;
        fontWeight: "bold";
    };
    userName: {
        marginTop: number;
        fontSize: number;
        color: string;
    };
};
//# sourceMappingURL=styles.d.ts.map