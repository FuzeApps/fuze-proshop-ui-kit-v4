export declare const styles: {
    icon: {
        backgroundColor: string;
        color: string;
        height: number;
        display: "flex";
        justifyContent: "center";
        alignItems: "center";
    };
    doneText: {
        fontSize: number;
        color: string;
    };
};
//# sourceMappingURL=styles.d.ts.map