import React from 'react';
import { type GestureResponderEvent } from 'react-native';
export default function DoneButton({ onDonePressed, buttonTxt, }: {
    navigation: any;
    buttonTxt?: string;
    onDonePressed: {
        (event: GestureResponderEvent): void;
    };
}): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map