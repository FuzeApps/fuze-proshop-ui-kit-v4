export declare const useStyles: () => {
    container: {
        flex: number;
        backgroundColor: string;
    };
    input: {
        backgroundColor: string;
        borderRadius: number;
        fontWeight: "400";
        width: "90%";
        paddingHorizontal: number;
        paddingVertical: number;
        color: string;
    };
    AllInputWrap: {
        backgroundColor: string;
        flex: number;
        marginTop: number;
    };
    InputWrap: {
        backgroundColor: string;
        flexDirection: "row";
        justifyContent: "space-between";
        paddingHorizontal: number;
        paddingBottom: number;
        paddingTop: number;
        alignItems: "flex-end";
        borderTopWidth: number;
        borderTopColor: string;
    };
    postDisabledBtn: {
        color: string;
        fontSize: number;
    };
    postBtnText: {
        color: string;
        fontSize: number;
    };
    postBtn: {
        marginHorizontal: number;
        marginBottom: number;
    };
    commentItem: {
        padding: number;
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    comment: {
        fontSize: number;
    };
    commentListWrap: {
        borderTopWidth: number;
        borderTopColor: string;
    };
    textInput: {
        borderWidth: number;
        borderBottomWidth: number;
        backgroundColor: string;
        fontSize: number;
        marginHorizontal: number;
        zIndex: number;
        paddingTop: number;
        width: "100%";
        borderRadius: number;
    };
    transparentText: {
        color: string;
    };
    inputContainer: {
        flex: number;
        paddingVertical: number;
        paddingHorizontal: number;
        backgroundColor: string;
        borderRadius: number;
    };
    mentionText: {
        color: string;
        fontSize: number;
    };
    inputText: {
        color: string;
        fontSize: number;
        letterSpacing: number;
    };
    overlay: {
        justifyContent: "center";
        alignItems: "flex-start";
        paddingHorizontal: number;
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    inputTextOverlayWrap: {
        flexDirection: "row";
        backgroundColor: string;
    };
    replyLabelWrap: {
        height: number;
        backgroundColor: string;
        paddingVertical: number;
        justifyContent: "space-between";
        flexDirection: "row";
        alignItems: "center";
    };
    replyLabel: {
        color: string;
        fontSize: number;
        paddingLeft: number;
        paddingRight: number;
    };
    closeIcon: {
        marginRight: number;
    };
    userNameLabel: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    commentListFooter: {
        width: number;
    };
};
//# sourceMappingURL=styles.d.ts.map