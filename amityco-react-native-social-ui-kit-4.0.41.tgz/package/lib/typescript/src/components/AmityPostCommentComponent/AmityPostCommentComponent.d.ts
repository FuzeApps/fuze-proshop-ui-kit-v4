import React from 'react';
import { PageID } from '../../enum';
type AmityPostCommentComponentType = {
    pageId?: PageID;
    postId: string;
    postType: Amity.CommentReferenceType;
    disabledInteraction?: boolean;
    setReplyUserName?: (arg: string) => void;
    setReplyCommentId?: (arg: string) => void;
    ListHeaderComponent?: JSX.Element;
};
declare const _default: React.NamedExoticComponent<AmityPostCommentComponentType>;
export default _default;
//# sourceMappingURL=AmityPostCommentComponent.d.ts.map