export declare const useStyles: () => {
    commentWrap: {
        backgroundColor: string;
        paddingHorizontal: number;
        width: "100%";
        alignSelf: "center";
    };
    replyCommentWrap: {
        backgroundColor: string;
        width: "100%";
        paddingTop: number;
    };
    headerSection: {
        paddingVertical: number;
        flexDirection: "row";
    };
    replyHeaderSection: {
        paddingTop: number;
        flexDirection: "row";
    };
    headerText: {
        fontWeight: "600";
        fontSize: number;
        color: string;
        marginBottom: number;
    };
    headerTextTime: {
        fontSize: number;
        fontWeight: "400";
        marginVertical: number;
        color: string;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginRight: number;
        backgroundColor: string;
        alignItems: "center";
        justifyContent: "center";
    };
    rightSection: {
        width: "90%";
    };
    commentBubble: {
        marginBottom: number;
        padding: number;
        backgroundColor: string;
        borderRadius: number;
        borderTopLeftRadius: number;
        alignSelf: "flex-start";
    };
    viewMoreReplyBtn: {
        width: number;
        borderRadius: number;
        backgroundColor: string;
        paddingVertical: number;
        paddingHorizontal: number;
        marginTop: number;
        flexDirection: "row";
        justifyContent: "center";
        alignItems: "center";
    };
    viewMoreText: {
        fontWeight: "600";
        color: string;
        paddingHorizontal: number;
    };
    commentText: {
        fontSize: number;
        color: string;
    };
    likeBtn: {
        flexDirection: "row";
        marginRight: number;
        alignItems: "center";
    };
    actionSection: {
        flex: number;
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "space-between";
    };
    rowContainer: {
        flexDirection: "row";
        alignItems: "center";
    };
    likedText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
        marginLeft: number;
    };
    btnText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
    };
    threeDots: {
        opacity: number;
        marginLeft: number;
    };
    modalContainer: {
        flex: number;
        justifyContent: "flex-end";
        backgroundColor: string;
    };
    modalContent: {
        backgroundColor: string;
        borderTopLeftRadius: number;
        borderTopRightRadius: number;
        padding: number;
        minHeight: number;
    };
    modalRow: {
        flexDirection: "row";
        alignItems: "center";
        padding: number;
        marginVertical: number;
    };
    handleBar: {
        alignSelf: "center";
        width: number;
        backgroundColor: string;
        height: number;
        marginVertical: number;
        borderRadius: number;
    };
    deleteText: {
        paddingLeft: number;
        fontWeight: "600";
        color: string;
    };
    twoOptions: {
        minHeight: number;
    };
    timeRow: {
        flexDirection: "row";
        alignItems: "center";
        marginRight: number;
    };
    dot: {
        color: string;
        fontWeight: "900";
        paddingHorizontal: number;
    };
    mentionText: {
        color: string;
        fontSize: number;
    };
    inputText: {
        color: string;
        fontSize: number;
    };
};
//# sourceMappingURL=styles.d.ts.map