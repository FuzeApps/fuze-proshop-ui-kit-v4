import React from 'react';
import { UserInterface } from '../../../types/user.interface';
import { IMentionPosition } from '../../../types/type';
export interface IComment {
    commentId: string;
    data: Record<string, any>;
    dataType: string | undefined;
    myReactions: string[];
    reactions: Record<string, number>;
    user: UserInterface | undefined;
    updatedAt: string | undefined;
    editedAt: string | undefined;
    createdAt: string;
    childrenComment: string[];
    referenceId: string;
    mentionees?: string[];
    mentionPosition?: IMentionPosition[];
    childrenNumber: number;
    targetType?: string;
    targetId?: string;
}
export interface ICommentList {
    commentDetail: IComment;
    isReplyComment?: boolean;
    onDelete: (commentId: string) => void;
    onClickReply: (user: UserInterface, commentId: string) => void;
    postType: Amity.CommentReferenceType;
    disabledInteraction?: boolean;
    onNavigate?: () => void;
}
declare const _default: React.MemoExoticComponent<({ commentDetail, onDelete, onClickReply, postType, disabledInteraction, onNavigate, }: ICommentList) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=CommentListItem.d.ts.map