export declare const useStyles: () => {
    mentionText: {
        color: string;
        fontSize: number;
    };
    inputText: {
        color: string;
        fontSize: number;
    };
    moreLessButton: {
        fontWeight: "normal";
        color: string;
        fontSize: number;
    };
};
//# sourceMappingURL=styles.d.ts.map