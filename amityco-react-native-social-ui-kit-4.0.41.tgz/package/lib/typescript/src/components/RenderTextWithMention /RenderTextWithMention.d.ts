import React from 'react';
import { IMentionPosition } from '../../types/type';
interface IrenderTextWithMention {
    mentionPositionArr: IMentionPosition[];
    textPost: string;
}
declare const _default: React.NamedExoticComponent<IrenderTextWithMention>;
export default _default;
//# sourceMappingURL=RenderTextWithMention.d.ts.map