import React from 'react';
declare const CategoryPills: ({ categoryIds }: {
    categoryIds: string[];
}) => React.JSX.Element;
export default CategoryPills;
//# sourceMappingURL=index.d.ts.map