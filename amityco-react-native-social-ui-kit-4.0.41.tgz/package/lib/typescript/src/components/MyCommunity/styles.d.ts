export declare const useStyle: () => {
    container: {
        backgroundColor: string;
        paddingVertical: number;
        paddingLeft: number;
    };
    title: {
        fontSize: number;
        fontWeight: "600";
        margin: number;
        color: string;
    };
    scrollView: {
        paddingTop: number;
        justifyContent: "space-between";
    };
    itemContainer: {
        alignItems: "center";
        marginRight: number;
        width: number;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
    };
    itemText: {
        fontSize: number;
        marginHorizontal: number;
        color: string;
    };
    textRow: {
        marginTop: number;
        flexDirection: "row";
        alignItems: "center";
    };
    titleContainer: {
        flexDirection: "row";
        justifyContent: "space-between";
    };
    arrowIcon: {
        marginRight: number;
        display: "flex";
    };
    seeAllBtn: {
        marginRight: number;
    };
    seeAllIcon: {
        width: number;
        height: number;
        borderRadius: number;
        backgroundColor: string;
        alignItems: "center";
        justifyContent: "center";
    };
    seeAllText: {
        fontSize: number;
        marginTop: number;
    };
};
//# sourceMappingURL=styles.d.ts.map