import React from 'react';
interface ICommunityItems {
    communityId: string;
    avatarFileId: string;
    displayName: string;
    isPublic: boolean;
    isOfficial: boolean;
}
declare const CommunityList: ({ item, onClickItem, }: {
    item: ICommunityItems;
    onClickItem: (id: string, name: string) => void;
}) => React.JSX.Element;
export default CommunityList;
//# sourceMappingURL=CommunityList.d.ts.map