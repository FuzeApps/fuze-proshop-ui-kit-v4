import { ImageProps } from 'react-native';
import React from 'react';
declare const _default: React.NamedExoticComponent<Partial<ImageProps>>;
export default _default;
//# sourceMappingURL=MyAvatar.d.ts.map