export declare const useStyles: () => {
    tabContainer: {
        flexDirection: "row";
        alignItems: "center";
        backgroundColor: string;
        padding: number;
    };
    tabBtn: {
        borderRadius: number;
        paddingHorizontal: number;
        paddingVertical: number;
        marginHorizontal: number;
        backgroundColor: string;
    };
    tabName: {
        fontSize: number;
        lineHeight: number;
        color: string;
    };
};
//# sourceMappingURL=styles.d.ts.map