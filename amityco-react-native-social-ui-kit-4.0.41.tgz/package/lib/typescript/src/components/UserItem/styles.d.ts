export declare const useStyles: () => {
    listItem: {
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "space-between";
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginRight: number;
    };
    itemText: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    leftContainer: {
        flexDirection: "row";
        alignItems: "center";
        flex: number;
        paddingHorizontal: number;
        paddingVertical: number;
    };
    rightContainer: {
        alignItems: "center";
        paddingHorizontal: number;
        minHeight: number;
        justifyContent: "center";
    };
    dotIcon: {
        width: number;
        height: number;
    };
    btnContainer: {
        padding: number;
    };
};
//# sourceMappingURL=styles.d.ts.map