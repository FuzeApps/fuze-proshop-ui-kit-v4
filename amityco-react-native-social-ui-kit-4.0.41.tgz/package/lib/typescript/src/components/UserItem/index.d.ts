import React from 'react';
import type { UserInterface } from '../../types/user.interface';
export default function UserItem({ user, isCheckmark, showThreeDot, onPress, onThreeDotTap, showActions, }: {
    user: UserInterface;
    isCheckmark?: boolean | undefined;
    showThreeDot?: boolean | undefined;
    showActions?: boolean | undefined;
    onPress?: (user: UserInterface) => void;
    onThreeDotTap?: (user: UserInterface) => void;
}): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map