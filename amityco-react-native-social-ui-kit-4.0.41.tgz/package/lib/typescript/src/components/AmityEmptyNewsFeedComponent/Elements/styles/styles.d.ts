export declare const useStyles: () => {
    icon: {
        width: number;
        height: number;
    };
    title: {
        fontSize: number;
        fontWeight: "600";
        color: string;
        marginVertical: number;
    };
    description: {
        fontSize: number;
        fontWeight: "400";
        color: string;
    };
    exploreBtn: {
        width: "60%";
        paddingHorizontal: number;
        paddingVertical: number;
        backgroundColor: string;
        borderRadius: number;
        marginVertical: number;
        justifyContent: "center";
        alignItems: "center";
        flexDirection: "row";
    };
    exploreIcon: {
        width: number;
        height: number;
    };
    exploreText: {
        color: string;
        fontSize: number;
        marginLeft: number;
    };
    createCommunityBtnText: {
        color: string;
        fontSize: number;
        lineHeight: number;
        fontWeight: "400";
    };
};
//# sourceMappingURL=styles.d.ts.map