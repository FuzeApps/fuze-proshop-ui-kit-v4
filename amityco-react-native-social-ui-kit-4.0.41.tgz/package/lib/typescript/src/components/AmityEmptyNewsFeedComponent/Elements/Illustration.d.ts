import React from 'react';
declare const _default: React.MemoExoticComponent<() => React.JSX.Element>;
export default _default;
//# sourceMappingURL=Illustration.d.ts.map