import React from 'react';
import { PageID } from '../../enum';
type AmityEmptyNewsFeedComponentType = {
    pageId?: PageID;
    onPressExploreCommunity?: () => void;
};
declare const _default: React.NamedExoticComponent<AmityEmptyNewsFeedComponentType>;
export default _default;
//# sourceMappingURL=AmityEmptyNewsFeedComponent.d.ts.map