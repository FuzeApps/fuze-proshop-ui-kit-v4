export declare const useStyles: () => {
    container: {
        flex: number;
        backgroundColor: string;
        justifyContent: "center";
        alignItems: "center";
    };
};
//# sourceMappingURL=styles.d.ts.map