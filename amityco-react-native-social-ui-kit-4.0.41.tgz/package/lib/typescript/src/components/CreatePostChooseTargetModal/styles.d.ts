export declare const useStyles: () => {
    container: {
        flex: number;
        backgroundColor: string;
        paddingTop: number;
    };
    header: {
        paddingTop: number;
        zIndex: number;
        padding: number;
        flexDirection: "row";
        alignItems: "center";
    };
    closeButton: {
        position: "absolute";
        left: number;
        bottom: number;
        zIndex: number;
        padding: number;
    };
    headerTextContainer: {
        flex: number;
        alignItems: "center";
        justifyContent: "center";
    };
    headerText: {
        fontWeight: "600";
        fontSize: number;
        textAlign: "center";
        color: string;
    };
    communityText: {
        marginLeft: number;
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    myCommunityText: {
        color: string;
        padding: number;
        opacity: number;
        fontSize: number;
    };
    rowContainer: {
        flexDirection: "row";
        alignItems: "center";
        paddingVertical: number;
        paddingHorizontal: number;
    };
    rowContainerMyTimeLine: {
        flexDirection: "row";
        alignItems: "center";
        paddingBottom: number;
        paddingTop: number;
        paddingHorizontal: number;
        borderBottomColor: string;
        borderBottomWidth: number;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginBottom: number;
        marginRight: number;
    };
    LoadingIndicator: {
        paddingVertical: number;
    };
};
//# sourceMappingURL=styles.d.ts.map