export declare const useStyles: () => {
    modalContainer: {
        flex: number;
        justifyContent: "flex-end";
        backgroundColor: string;
    };
    modalContent: {
        backgroundColor: string;
        borderTopLeftRadius: number;
        borderTopRightRadius: number;
        padding: number;
        minHeight: number;
    };
    scrollContentContainer: {
        flexGrow: number;
        justifyContent: "flex-end";
    };
    modalText: {
        fontSize: number;
        marginBottom: number;
        textAlign: "center";
    };
    closeButton: {
        backgroundColor: string;
        borderRadius: number;
        paddingVertical: number;
        paddingHorizontal: number;
        marginTop: number;
    };
    modalRow: {
        flexDirection: "row";
        alignItems: "center";
        padding: number;
        marginVertical: number;
    };
    closeButtonText: {
        color: string;
        fontSize: number;
        fontWeight: "bold";
        textAlign: "center";
    };
    postText: {
        paddingLeft: number;
        fontWeight: "600";
        color: string;
    };
    invisible: {
        display: "none";
    };
    visible: {
        display: "flex";
    };
    btnWrap: {
        padding: number;
    };
};
//# sourceMappingURL=style.d.ts.map