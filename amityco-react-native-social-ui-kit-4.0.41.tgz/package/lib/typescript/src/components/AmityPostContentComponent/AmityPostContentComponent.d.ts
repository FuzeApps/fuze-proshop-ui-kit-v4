import React from 'react';
import { PageID } from '../../enum';
import { IMentionPosition } from '../../types/type';
import type { UserInterface } from '../../types/user.interface';
import { AmityPostContentComponentStyleEnum } from '../../enum/AmityPostContentComponentStyle';
import { PostTargetType } from '../../enum/postTargetType';
export interface IPost {
    postId: string;
    data: Record<string, any>;
    dataType: string | undefined;
    myReactions: string[];
    reactionCount: Record<string, number>;
    commentsCount: number;
    user: UserInterface | undefined;
    updatedAt: string | undefined;
    editedAt: string | undefined;
    createdAt: string;
    targetType: PostTargetType;
    targetId: string;
    childrenPosts: string[];
    mentionees: string[];
    mentionPosition?: IMentionPosition[];
    analytics: Amity.Post<'analytics'>;
    tags: string[];
}
export interface IPostList {
    post: IPost;
    pageId?: PageID;
    AmityPostContentComponentStyle?: AmityPostContentComponentStyleEnum;
    isFromCommunityFeed?: boolean;
}
export interface MediaUri {
    uri: string;
}
export interface IVideoPost {
    thumbnailFileId: string;
    videoFileId: {
        original: string;
    };
}
declare const _default: React.MemoExoticComponent<({ pageId, post, AmityPostContentComponentStyle, isFromCommunityFeed, }: IPostList) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=AmityPostContentComponent.d.ts.map