export declare const styles: {
    sectionHeader: {
        backgroundColor: string;
        paddingVertical: number;
        paddingHorizontal: number;
    };
    sectionHeaderText: {
        fontWeight: "600";
        fontSize: number;
        color: string;
    };
};
//# sourceMappingURL=styles.d.ts.map