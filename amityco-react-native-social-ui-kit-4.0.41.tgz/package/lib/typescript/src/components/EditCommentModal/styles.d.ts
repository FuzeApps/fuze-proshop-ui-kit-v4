export declare const useStyles: () => {
    container: {
        flex: number;
        backgroundColor: string;
        paddingTop: number;
        paddingHorizontal: number;
    };
    header: {
        paddingTop: number;
        zIndex: number;
        padding: number;
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "space-between";
    };
    closeButton: {
        zIndex: number;
        padding: number;
    };
    headerTextContainer: {
        alignItems: "center";
        justifyContent: "center";
    };
    headerText: {
        fontWeight: "600";
        fontSize: number;
        textAlign: "center";
        color: string;
    };
    textInput: {
        borderWidth: number;
        borderBottomWidth: number;
        backgroundColor: string;
        fontSize: number;
        marginHorizontal: number;
        color: string;
        height: number;
    };
    AllInputWrap: {
        backgroundColor: string;
        flex: number;
    };
    InputWrap: {
        backgroundColor: string;
        width: "100%";
        flexDirection: "row";
        justifyContent: "space-around";
        paddingHorizontal: number;
        paddingBottom: number;
        paddingTop: number;
        alignItems: "center";
        borderTopWidth: number;
        borderTopColor: string;
    };
};
//# sourceMappingURL=styles.d.ts.map