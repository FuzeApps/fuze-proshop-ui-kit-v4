export declare const styles: {
    overlay: {
        backgroundColor: string;
        zIndex: number;
        alignItems: "center";
        justifyContent: "center";
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    indicatorContainer: {
        padding: number;
        borderRadius: number;
        alignItems: "center";
    };
    loadingText: {
        marginTop: number;
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
};
//# sourceMappingURL=styles.d.ts.map