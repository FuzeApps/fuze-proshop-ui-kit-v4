export declare const useStyles: () => {
    headerWrap: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
        backgroundColor: string;
    };
    inputWrap: {
        marginHorizontal: number;
        backgroundColor: string;
        paddingHorizontal: number;
        paddingVertical: number;
        borderRadius: number;
        flexDirection: "row";
        justifyContent: "space-between";
        marginVertical: number;
        flex: number;
        alignItems: "center";
    };
    input: {
        flex: number;
        marginHorizontal: number;
        color: string;
    };
    cancelBtn: {
        marginRight: number;
        color: string;
    };
    searchIcon: {
        width: number;
        height: number;
        tintColor: string;
    };
};
//# sourceMappingURL=styles.d.ts.map