import React from 'react';
type AmityTopSearchBarComponentType = {
    setSearchValue: (arg: string) => void;
};
declare const _default: React.MemoExoticComponent<({ setSearchValue, }: AmityTopSearchBarComponentType) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=AmityTopSearchBarComponent.d.ts.map