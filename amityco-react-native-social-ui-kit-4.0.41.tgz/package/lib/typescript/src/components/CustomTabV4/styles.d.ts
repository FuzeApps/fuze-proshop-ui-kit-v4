export declare const useStyles: () => {
    wrapper: {
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    scrollViewWrapper: {
        backgroundColor: string;
        paddingHorizontal: number;
    };
    container: {
        flexDirection: "row";
        backgroundColor: string;
        justifyContent: "center";
        paddingTop: number;
        minHeight: number;
        alignItems: "flex-end";
    };
    tab: {
        flex: number;
        borderBottomWidth: number;
        borderBottomColor: string;
        alignItems: "center";
        paddingBottom: number;
    };
    activeTab: {
        borderBottomColor: string;
    };
    activeTabText: {
        color: string;
    };
    indicator: {
        position: "absolute";
        bottom: number;
        height: number;
        backgroundColor: string;
    };
    tabItem: {
        flex: number;
        justifyContent: "center";
        alignItems: "center";
    };
    tabText: {
        color: string;
        fontSize: number;
        fontWeight: "normal" | "bold" | "100" | "200" | "300" | "400" | "500" | "600" | "700" | "800" | "900";
        textAlign: "center";
    };
    icon: {
        marginBottom: number;
    };
};
//# sourceMappingURL=styles.d.ts.map