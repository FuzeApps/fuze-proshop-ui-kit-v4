import { type ReactElement } from 'react';
import { TabName } from '../../enum/tabNameState';
interface ICustomTab {
    onTabChange?: (tabName: TabName) => void;
    tabName: TabName[];
}
declare const CustomTabV4: ({ tabName, onTabChange }: ICustomTab) => ReactElement;
export default CustomTabV4;
//# sourceMappingURL=index.d.ts.map