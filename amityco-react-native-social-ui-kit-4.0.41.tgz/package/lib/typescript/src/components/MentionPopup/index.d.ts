import React from 'react';
import { ISearchItem } from '../SearchItem';
export default function MentionPopup({ userName, onSelectMention, }: {
    userName: string;
    onSelectMention: (target: ISearchItem) => void;
}): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map