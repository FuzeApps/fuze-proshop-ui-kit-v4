export declare const useStyles: () => {
    mentionContainer: {
        borderTopColor: string;
        borderTopWidth: number;
        paddingHorizontal: number;
        maxHeight: number;
    };
};
//# sourceMappingURL=styles.d.ts.map