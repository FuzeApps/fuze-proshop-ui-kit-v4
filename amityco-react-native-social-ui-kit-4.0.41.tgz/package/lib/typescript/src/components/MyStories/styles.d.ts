export declare const useStyles: () => {
    container: {
        backgroundColor: string;
        paddingVertical: number;
        borderBottomColor: string;
        borderBottomWidth: number;
    };
    title: {
        fontSize: number;
        fontWeight: "600";
        margin: number;
        color: string;
    };
    scrollView: {
        justifyContent: "space-between";
    };
    itemContainer: {
        alignItems: "center";
        marginLeft: number;
        width: number;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        margin: number;
    };
    itemText: {
        fontSize: number;
        fontWeight: "400";
        color: string;
    };
    textRow: {
        marginTop: number;
        flexDirection: "row";
        alignItems: "center";
    };
    titleContainer: {
        flexDirection: "row";
        justifyContent: "space-between";
    };
    arrowIcon: {
        marginRight: number;
        display: "flex";
    };
    seeAllBtn: {
        marginRight: number;
    };
    seeAllIcon: {
        width: number;
        height: number;
        borderRadius: number;
        backgroundColor: string;
        alignItems: "center";
        justifyContent: "center";
    };
    seeAllText: {
        fontSize: number;
        marginTop: number;
    };
    storyRing: {
        position: "absolute";
    };
    officialIcon: {
        position: "absolute";
        left: number;
        top: number;
    };
};
//# sourceMappingURL=styles.d.ts.map