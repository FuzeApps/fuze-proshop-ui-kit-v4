import type { MyMD3Theme } from './../../providers/amity-ui-kit-provider';
export declare const useStyles: (theme: MyMD3Theme) => {
    container: {
        flex: number;
        backgroundColor: string;
        paddingHorizontal: number;
        borderTopWidth: number;
        borderColor: string;
    };
    communityItemContainer: {
        paddingVertical: number;
        flexDirection: "row";
        alignItems: "center";
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    communityInfoContainer: {
        flex: number;
        paddingStart: number;
    };
    communityNameContainer: {
        flexDirection: "row";
        alignItems: "center";
    };
    communityName: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    privateBadge: {
        width: number;
        height: number;
        tintColor: string;
    };
    officialBadge: {
        width: number;
        height: number;
        marginLeft: number;
    };
    communityCategoryContainer: {
        flexDirection: "row";
        marginVertical: number;
        flex: number;
    };
    categoryName: {
        paddingHorizontal: number;
        paddingVertical: number;
        backgroundColor: string;
        color: string;
        borderRadius: number;
        overflow: "hidden";
        marginHorizontal: number;
        fontSize: number;
        maxWidth: "30%";
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
    };
    communityCount: {
        color: string;
        fontSize: number;
    };
    skeletonLoadingContainer: {
        borderBottomWidth: number;
        borderColor: string;
        paddingVertical: number;
    };
};
//# sourceMappingURL=styles.d.ts.map