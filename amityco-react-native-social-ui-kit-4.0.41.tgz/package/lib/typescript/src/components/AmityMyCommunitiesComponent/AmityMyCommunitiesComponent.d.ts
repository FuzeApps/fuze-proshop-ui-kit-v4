import React from 'react';
import { ComponentID, PageID } from '../../enum';
type AmityMyCommunitiesComponentType = {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const _default: React.NamedExoticComponent<AmityMyCommunitiesComponentType>;
export default _default;
//# sourceMappingURL=AmityMyCommunitiesComponent.d.ts.map