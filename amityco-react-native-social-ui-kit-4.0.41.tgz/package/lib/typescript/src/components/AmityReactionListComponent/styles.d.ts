export declare const useStyles: () => {
    container: {
        width: number;
        height: number;
        backgroundColor: string;
    };
    modal: {
        borderTopLeftRadius: number;
        borderTopRightRadius: number;
        backgroundColor: string;
        width: number;
        height: number;
    };
    modalContainer: {
        paddingTop: number;
        alignItems: "center";
        flex: number;
        paddingBottom: number;
    };
    handleBar: {
        width: number;
        backgroundColor: string;
        height: number;
        marginVertical: number;
        borderRadius: number;
    };
    errorContainer: {
        width: "100%";
        flex: number;
        justifyContent: "center";
        alignItems: "center";
    };
    errorTitle: {
        marginTop: number;
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    errorDesc: {
        marginTop: number;
        fontSize: number;
        fontWeight: "400";
        color: string;
        textAlign: "center";
    };
    reactionHeaderRow: {
        width: "100%";
        flexDirection: "row";
        alignItems: "center";
        paddingHorizontal: number;
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    reactionBtn: {
        marginRight: number;
        paddingBottom: number;
        alignItems: "center";
        justifyContent: "center";
        minWidth: number;
        flexDirection: "row";
    };
    selectedReactionBtn: {
        borderBottomWidth: number;
        borderColor: string;
    };
    reaction: {
        fontSize: number;
        fontWeight: "bold";
        color: string;
        marginLeft: number;
    };
    selectedReaction: {
        color: string;
    };
    rowContainer: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
        marginVertical: number;
        paddingHorizontal: number;
    };
    reactorNameContainer: {
        flexDirection: "row";
        justifyContent: "flex-start";
        alignItems: "center";
    };
    avater: {
        width: number;
        height: number;
        borderRadius: number;
    };
    userName: {
        color: string;
        fontSize: number;
        fontWeight: "500";
        marginLeft: number;
    };
};
//# sourceMappingURL=styles.d.ts.map