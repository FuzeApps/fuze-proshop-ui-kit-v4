import type { MyMD3Theme } from '../../../providers/amity-ui-kit-provider';
export declare const useStyles: (theme: MyMD3Theme) => {
    detailActionSection: {
        borderBottomWidth: number;
        borderBottomColor: string;
    };
    actionSection: {
        flexDirection: "row";
        marginTop: number;
        marginBottom: number;
        paddingVertical: number;
        alignItems: "center";
        justifyContent: "space-between";
    };
    joinBannerSection: {
        padding: number;
        backgroundColor: string;
        borderRadius: number;
        alignItems: "center";
        justifyContent: "center";
        flexDirection: "column";
    };
    joinBannerText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
        paddingTop: number;
        paddingStart: number;
        textAlign: "center";
    };
    btnText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
        marginHorizontal: number;
    };
    likeBtn: {
        flexDirection: "row";
        paddingRight: number;
        alignItems: "center";
    };
    commentBtn: {
        flexDirection: "row";
        paddingHorizontal: number;
        alignItems: "center";
    };
    likedText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
        marginHorizontal: number;
    };
    countSection: {
        marginVertical: number;
        flexDirection: "row";
        justifyContent: "space-between";
    };
    likeCountText: {
        fontSize: number;
        color: string;
    };
    commentCountText: {
        fontSize: number;
        color: string;
    };
    row: {
        flexDirection: "row";
        alignItems: "center";
    };
};
//# sourceMappingURL=styles.d.ts.map