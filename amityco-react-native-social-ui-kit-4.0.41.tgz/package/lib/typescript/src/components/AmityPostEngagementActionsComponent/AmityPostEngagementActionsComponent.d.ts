import React from 'react';
import { AmityPostContentComponentStyleEnum } from '../../enum/AmityPostContentComponentStyle';
import { ComponentID, PageID } from '../../enum';
import { PostTargetType } from '../../enum/postTargetType';
type AmityPostEngagementActionsComponentType = {
    AmityPostContentComponentStyle?: AmityPostContentComponentStyleEnum;
    targetId: string;
    targetType: PostTargetType;
    postId: string;
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const _default: React.NamedExoticComponent<AmityPostEngagementActionsComponentType>;
export default _default;
//# sourceMappingURL=AmityPostEngagementActionsComponent.d.ts.map