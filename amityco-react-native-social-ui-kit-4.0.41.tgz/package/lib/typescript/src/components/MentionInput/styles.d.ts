export declare const useStyles: () => {
    mentionListContainer: {
        marginTop: number;
        width: "100%";
        maxHeight: number;
        top: number;
        backgroundColor: string;
        borderWidth: number;
        borderColor: string;
        borderRadius: number;
    };
    mentionContainer: {
        padding: number;
        flexDirection: "row";
        alignItems: "center";
    };
    avatar: {
        width: number;
        height: number;
        marginRight: number;
    };
    mentionUserName: {
        fontSize: number;
        color: string;
    };
    mentionText: {
        color: string;
        fontSize: number;
    };
    inputContainer: {
        width: "100%";
    };
    inputText: {
        color: string;
        fontSize: number;
        padding: number;
        maxHeight: number;
    };
    textInput: {
        marginTop: number;
        fontSize: number;
        width: "100%";
    };
    transparentText: {
        color: string;
    };
    overlay: {
        justifyContent: "center";
        alignItems: "flex-start";
        paddingHorizontal: number;
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
};
//# sourceMappingURL=styles.d.ts.map