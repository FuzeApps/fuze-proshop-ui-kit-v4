import { TextInputProps, TextInput } from 'react-native';
import React, { Ref } from 'react';
import { IMentionPosition } from '../../types/type';
import { TSearchItem } from '../../hooks';
interface IMentionInput extends TextInputProps {
    setInputMessage: (inputMessage: string) => void;
    mentionsPosition: IMentionPosition[];
    setMentionsPosition: (mentionsPosition: IMentionPosition[]) => void;
    mentionUsers: TSearchItem[];
    setMentionUsers: (mentionUsers: TSearchItem[]) => void;
    isBottomMentionSuggestionsRender: boolean;
    privateCommunityId?: string;
    initialValue?: string;
    resetValue?: boolean;
    inputRef?: Ref<TextInput>;
    setIsShowingSuggestion?: (arg: boolean) => void;
}
declare const _default: React.NamedExoticComponent<IMentionInput>;
export default _default;
//# sourceMappingURL=AmityMentionInput.d.ts.map