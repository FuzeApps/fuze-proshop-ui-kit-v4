import React from 'react';
interface IPollSection {
    pollId: string;
}
declare const _default: React.NamedExoticComponent<IPollSection>;
export default _default;
//# sourceMappingURL=PollSection.d.ts.map