import React from 'react';
interface IPollBar {
    myVote: boolean;
    length: number;
}
declare const _default: React.NamedExoticComponent<IPollBar>;
export default _default;
//# sourceMappingURL=PollBar.d.ts.map