import React from 'react';
interface IPollOptionList {
    options: Amity.PollAnswer[];
    answerType: Amity.PollAnswerType;
    isAlreadyVoted: boolean;
    isPollClosed: boolean;
    totalVote: number;
    onSubmit: (selectedOption: string[]) => void;
}
declare const _default: React.NamedExoticComponent<IPollOptionList>;
export default _default;
//# sourceMappingURL=PollOptionList.d.ts.map