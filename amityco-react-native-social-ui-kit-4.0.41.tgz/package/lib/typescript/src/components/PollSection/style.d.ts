export declare const useStyles: () => {
    container: {
        paddingVertical: number;
    };
    rowContainer: {
        flexDirection: "row";
        justifyContent: "space-between";
        alignItems: "center";
        marginVertical: number;
    };
    pollEndDays: {
        fontWeight: "700";
        color: string;
    };
    totalVote: {
        fontSize: number;
        color: string;
    };
    voteCount: {
        color: string;
    };
    pollOptionContainer: {
        borderWidth: number;
        borderColor: string;
        borderRadius: number;
        padding: number;
        marginVertical: number;
    };
    pollOptionContainerRow: {
        flexDirection: "row";
        alignItems: "flex-start";
    };
    optionText: {
        flex: number;
        fontSize: number;
        color: string;
        marginLeft: number;
        fontWeight: "500";
    };
    submitBtn: {
        marginTop: number;
        width: "100%";
        justifyContent: "center";
        alignItems: "center";
    };
    submit: {
        fontWeight: "bold";
        color: string;
    };
    moreOptionsBtn: {
        marginTop: number;
        width: "100%";
        justifyContent: "center";
        alignItems: "center";
        borderWidth: number;
        borderColor: string;
        borderRadius: number;
        paddingVertical: number;
    };
    moreOptionsText: {
        color: string;
    };
    selectedOptionContainer: {
        borderColor: string;
    };
    backgroundBar: {
        width: "100%";
        height: number;
        borderRadius: number;
        backgroundColor: string;
        marginTop: number;
    };
    innerBar: {
        backgroundColor: string;
        flex: number;
        borderRadius: number;
    };
    myVoteBar: {
        backgroundColor: string;
    };
    onResultOption: {
        borderLeftWidth: number;
        borderColor: string;
    };
};
//# sourceMappingURL=style.d.ts.map