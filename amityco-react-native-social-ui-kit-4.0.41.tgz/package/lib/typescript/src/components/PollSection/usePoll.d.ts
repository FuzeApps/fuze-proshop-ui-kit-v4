export declare const usePoll: (pollId: string, shouldFetch: boolean) => {
    data: Amity.RawPoll;
    endDays: number;
    totalVote: number;
    isPollClosed: boolean;
    isAlreadyVoted: boolean;
};
//# sourceMappingURL=usePoll.d.ts.map