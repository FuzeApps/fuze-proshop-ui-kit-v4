import React from 'react';
import type { IPost, IVideoPost } from '../Social/PostList';
interface IModal {
    visible: boolean;
    userId?: string;
    onClose: () => void;
    onFinishEdit: (postData: {
        text: string;
        mediaUrls: string[] | IVideoPost[];
    }, type: string) => void;
    postDetail: IPost;
    videoPostsArr?: IVideoPost[];
    imagePostsArr?: string[];
    privateCommunityId: string | null;
}
declare const _default: React.MemoExoticComponent<({ visible, onClose, postDetail, onFinishEdit, privateCommunityId, }: IModal) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=index.d.ts.map