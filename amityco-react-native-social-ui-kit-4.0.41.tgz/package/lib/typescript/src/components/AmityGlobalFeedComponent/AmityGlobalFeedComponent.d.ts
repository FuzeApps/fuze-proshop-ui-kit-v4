import React from 'react';
import { PageID } from '../../enum/enumUIKitID';
type AmityGlobalFeedComponentType = {
    pageId?: PageID;
};
declare const _default: React.NamedExoticComponent<AmityGlobalFeedComponentType>;
export default _default;
//# sourceMappingURL=AmityGlobalFeedComponent.d.ts.map