import type { MyMD3Theme } from '../../providers/amity-ui-kit-provider';
export declare const useStyle: (themeStyle: MyMD3Theme) => {
    feedWrap: {
        backgroundColor: string;
        height: "100%";
    };
    contentContainerStyle: {
        paddingBottom: number;
    };
};
//# sourceMappingURL=styles.d.ts.map