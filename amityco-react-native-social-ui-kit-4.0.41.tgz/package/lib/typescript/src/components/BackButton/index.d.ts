import React from 'react';
interface IBackBtn {
    onPress?: () => any;
    goBack?: boolean;
    backTwice?: boolean;
}
export default function BackButton({ onPress, goBack, backTwice, }: IBackBtn): React.JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map