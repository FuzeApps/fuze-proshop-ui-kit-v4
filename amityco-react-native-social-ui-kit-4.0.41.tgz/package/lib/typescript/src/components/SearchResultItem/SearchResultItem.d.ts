import React from 'react';
import { ComponentID, PageID, TabName } from '../../enum';
type SearchResultItemType = {
    pageId?: PageID;
    componentId?: ComponentID;
    item: Amity.User & Amity.RawCommunity;
    searchType: TabName;
};
declare const _default: React.NamedExoticComponent<SearchResultItemType>;
export default _default;
//# sourceMappingURL=SearchResultItem.d.ts.map