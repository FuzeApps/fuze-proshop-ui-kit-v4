import type { MyMD3Theme } from '../../providers/amity-ui-kit-provider';
export declare const useStyles: (theme: MyMD3Theme) => {
    container: {
        backgroundColor: string;
        flexDirection: "row";
        paddingHorizontal: number;
        alignItems: "center";
        marginVertical: number;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
    };
    profileInfoContainer: {
        marginLeft: number;
        justifyContent: "center";
    };
    category: {
        marginVertical: number;
        alignSelf: "flex-start";
        paddingHorizontal: number;
        paddingVertical: number;
        backgroundColor: string;
        color: string;
        borderRadius: number;
        overflow: "hidden";
        marginHorizontal: number;
        fontSize: number;
    };
    memberCounts: {
        fontSize: number;
        fontWeight: "400";
        color: string;
        marginVertical: number;
    };
    rowContainer: {
        justifyContent: "center";
        flexDirection: "row";
    };
    diaplayName: {
        fontWeight: "600";
        fontSize: number;
        color: string;
    };
    lockIcon: {
        width: number;
        height: number;
        tintColor: string;
    };
    badgeIcon: {
        width: number;
        height: number;
    };
};
//# sourceMappingURL=styles.d.ts.map