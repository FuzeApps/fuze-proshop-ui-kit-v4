export declare const useStyles: () => {
    image: {
        width: "100%";
        height: number;
        alignSelf: "center";
        backgroundColor: string;
    };
    metadataContainer: {
        marginTop: number;
        borderRadius: number;
        borderWidth: number;
        borderColor: string;
        overflow: "hidden";
    };
    metadataTextContainer: {
        padding: number;
    };
    title: {
        fontWeight: "bold";
        fontSize: number;
        color: string;
    };
    shortUrl: {
        fontSize: number;
        color: string;
        marginBottom: number;
    };
};
//# sourceMappingURL=styles.d.ts.map