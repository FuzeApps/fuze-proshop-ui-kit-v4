import * as React from 'react';
import { IMentionPosition } from '../../types/type';
export interface LinkPreviewProps {
    text: string;
    mentionPositionArr: IMentionPosition[];
}
export declare const LinkPreview: React.MemoExoticComponent<({ text, mentionPositionArr }: LinkPreviewProps) => React.JSX.Element>;
//# sourceMappingURL=LinkPreview.d.ts.map