export declare const useStyles: () => {
    container: {
        paddingVertical: number;
        flex: number;
        gap: number;
    };
    postCard: {
        backgroundColor: string;
        paddingHorizontal: number;
    };
    storiesContainer: {
        flexDirection: "row";
    };
};
//# sourceMappingURL=styles.d.ts.map