import React from 'react';
declare const NewsFeedLoadingComponent: () => React.JSX.Element;
export default NewsFeedLoadingComponent;
//# sourceMappingURL=NewsFeedLoadingComponent.d.ts.map