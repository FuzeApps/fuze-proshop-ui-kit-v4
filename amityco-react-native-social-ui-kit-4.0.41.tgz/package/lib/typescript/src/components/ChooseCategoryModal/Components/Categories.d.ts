import React from 'react';
declare const _default: React.MemoExoticComponent<({ item, onSelectCategory, }: {
    item: Amity.Category;
    onSelectCategory: (id: string, name: string) => void;
}) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=Categories.d.ts.map