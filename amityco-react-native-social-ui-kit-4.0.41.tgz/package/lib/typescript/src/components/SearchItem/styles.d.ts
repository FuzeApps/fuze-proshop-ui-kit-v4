export declare const useStyles: () => {
    listItem: {
        flexDirection: "row";
        alignItems: "center";
        justifyContent: "space-between";
        paddingVertical: number;
        paddingHorizontal: number;
        backgroundColor: string;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginRight: number;
    };
    itemText: {
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    leftContainer: {
        flexDirection: "row";
        alignItems: "center";
    };
    dotIcon: {
        width: number;
        height: number;
    };
    categoryText: {
        fontSize: number;
        color: string;
        marginTop: number;
    };
};
//# sourceMappingURL=styles.d.ts.map