import { StyleSheet } from 'react-native';
export declare const useStyles: () => StyleSheet.NamedStyles<any> | StyleSheet.NamedStyles<{
    postWrap: {
        backgroundColor: string;
        marginTop: number;
        paddingHorizontal: number;
        paddingTop: number;
    };
    headerSection: {
        paddingVertical: number;
        flexDirection: "row";
        justifyContent: "space-between";
    };
    headerText: {
        fontWeight: "600";
        fontSize: number;
        color: string;
    };
    user: {
        paddingVertical: number;
        flexDirection: "row";
        maxWidth: number;
    };
    headerTextTime: {
        fontSize: number;
        fontWeight: "400";
        color: string;
        marginVertical: number;
    };
    bodySection: {
        justifyContent: "center";
        paddingVertical: number;
        minHeight: number;
    };
    countSection: {
        marginVertical: number;
        flexDirection: "row";
        justifyContent: "space-between";
    };
    likeCountText: {
        fontSize: number;
        color: string;
    };
    commentCountText: {
        fontSize: number;
        color: string;
    };
    bodyText: {
        fontSize: number;
        fontStyle: "normal";
        fontWeight: "400";
        marginBottom: number;
        color: string;
    };
    actionSection: {
        borderTopColor: string;
        borderTopWidth: number;
        flexDirection: "row";
        paddingVertical: number;
        width: "100%";
    };
    acceptBtn: {
        flexDirection: "row";
        paddingVertical: number;
        backgroundColor: string;
        justifyContent: "center";
        marginRight: number;
        borderRadius: number;
        flex: number;
    };
    declineBtn: {
        width: "100%";
        flexDirection: "row";
        paddingVertical: number;
        justifyContent: "center";
        marginLeft: number;
        borderWidth: number;
        borderColor: string;
        borderRadius: number;
        flex: number;
    };
    acceptBtnText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
    };
    declineBtnText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
        marginHorizontal: number;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginRight: number;
        backgroundColor: string;
        alignItems: "center";
        justifyContent: "center";
    };
    likedText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
        marginHorizontal: number;
    };
    headerRow: {
        flexDirection: "row";
        alignItems: "center";
    };
    arrow: {
        marginHorizontal: number;
    };
    imageLargePost: {
        height: number;
        borderRadius: number;
        resizeMode: "cover";
    };
    imageMediumLargePost: {
        height: number;
        borderRadius: number;
    };
    imageMediumPost: {
        height: number;
        borderRadius: number;
    };
    imageSmallPost: {
        height: number;
        borderRadius: number;
    };
    imageMarginRight: {
        marginRight: number;
    };
    imageMarginLeft: {
        marginLeft: number;
    };
    imageMarginTop: {
        marginTop: number;
    };
    imageMarginBottom: {
        marginBottom: number;
    };
    imagesWrap: {
        display: "flex";
        flex: number;
        marginTop: number;
        marginBottom: number;
        width: "100%";
    };
    row: {
        flexDirection: "row";
    };
    col2: {
        flex: number;
    };
    col3: {
        flex: number;
    };
    col6: {
        flex: number;
    };
    overlay: {
        backgroundColor: string;
        justifyContent: "center";
        alignItems: "center";
        borderRadius: number;
        marginTop: number;
        marginLeft: number;
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    overlayText: {
        color: string;
        fontSize: number;
        fontWeight: "bold";
    };
    container: {
        flex: number;
        position: "absolute";
        top: number;
        bottom: number;
        left: number;
        right: number;
        backgroundColor: string;
        justifyContent: "center";
        alignItems: "center";
    };
    playButton: {
        width: number;
        height: number;
        borderRadius: number;
        position: "absolute";
        top: "50%";
        left: "50%";
        transform: ({
            translateX: number;
            translateY?: undefined;
        } | {
            translateY: number;
            translateX?: undefined;
        })[];
        zIndex: number;
    };
    videoContainer: {
        flex: number;
        backgroundColor: string;
        alignItems: "center";
        justifyContent: "center";
    };
    video: {
        alignSelf: "center";
        width: number;
        height: number;
    };
    mediaWrap: {
        minHeight: number;
    };
    threeDots: {
        padding: number;
    };
    modalContainer: {
        flex: number;
        justifyContent: "flex-end";
        backgroundColor: string;
    };
    modalContent: {
        backgroundColor: string;
        borderTopLeftRadius: number;
        borderTopRightRadius: number;
        padding: number;
        minHeight: number;
    };
    twoOptions: {
        minHeight: number;
    };
    modalRow: {
        flexDirection: "row";
        alignItems: "center";
        padding: number;
        marginVertical: number;
    };
    deleteText: {
        paddingLeft: number;
        fontWeight: "600";
        color: string;
    };
    timeRow: {
        flexDirection: "row";
        alignItems: "center";
    };
    dot: {
        color: string;
        fontWeight: "900";
        paddingHorizontal: number;
    };
    mentionText: {
        color: string;
        fontSize: number;
    };
    inputText: {
        color: string;
        fontSize: number;
    };
}>;
//# sourceMappingURL=styles.d.ts.map