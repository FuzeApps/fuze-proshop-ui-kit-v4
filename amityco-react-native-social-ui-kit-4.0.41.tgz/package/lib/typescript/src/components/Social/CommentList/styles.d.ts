export declare const useStyles: () => {
    commentWrap: {
        backgroundColor: string;
        paddingHorizontal: number;
        width: "100%";
        alignSelf: "center";
    };
    replyCommentWrap: {
        backgroundColor: string;
        width: "100%";
        paddingTop: number;
    };
    headerSection: {
        paddingVertical: number;
        flexDirection: "row";
    };
    replyHeaderSection: {
        paddingTop: number;
        flexDirection: "row";
    };
    headerText: {
        fontWeight: "600";
        fontSize: number;
        marginTop: number;
        color: string;
    };
    headerTextTime: {
        fontSize: number;
        fontWeight: "400";
        marginVertical: number;
        color: string;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginRight: number;
        backgroundColor: string;
        alignItems: "center";
        justifyContent: "center";
    };
    headerRow: {
        flexDirection: "row";
        alignItems: "center";
    };
    rightSection: {
        width: "90%";
    };
    commentBubble: {
        padding: number;
        backgroundColor: string;
        marginVertical: number;
        borderRadius: number;
        borderTopLeftRadius: number;
        alignSelf: "flex-start";
    };
    viewMoreReplyBtn: {
        width: number;
        borderRadius: number;
        backgroundColor: string;
        paddingVertical: number;
        paddingHorizontal: number;
        marginTop: number;
        flexDirection: "row";
        justifyContent: "center";
        alignItems: "center";
    };
    viewMoreText: {
        fontWeight: "600";
        color: string;
        paddingHorizontal: number;
    };
    commentText: {
        fontSize: number;
        color: string;
    };
    likeBtn: {
        flexDirection: "row";
        paddingRight: number;
        paddingTop: number;
    };
    actionSection: {
        flexDirection: "row";
    };
    likedText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
        marginHorizontal: number;
    };
    btnText: {
        color: string;
        fontSize: number;
        fontWeight: "600";
        marginHorizontal: number;
    };
    threeDots: {
        padding: number;
        opacity: number;
    };
    modalContainer: {
        flex: number;
        justifyContent: "flex-end";
        backgroundColor: string;
    };
    modalContent: {
        backgroundColor: string;
        borderTopLeftRadius: number;
        borderTopRightRadius: number;
        padding: number;
        minHeight: number;
    };
    modalRow: {
        flexDirection: "row";
        alignItems: "center";
        padding: number;
        marginVertical: number;
    };
    deleteText: {
        paddingLeft: number;
        fontWeight: "600";
        color: string;
    };
    twoOptions: {
        minHeight: number;
    };
    timeRow: {
        flexDirection: "row";
        alignItems: "center";
    };
    dot: {
        color: string;
        fontWeight: "900";
        paddingHorizontal: number;
    };
    mentionText: {
        color: string;
        fontSize: number;
    };
    inputText: {
        color: string;
        fontSize: number;
    };
};
//# sourceMappingURL=styles.d.ts.map