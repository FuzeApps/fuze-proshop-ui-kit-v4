import { StyleSheet } from 'react-native';
export declare const createStyles: () => StyleSheet.NamedStyles<any> | StyleSheet.NamedStyles<{
    container: {
        flex: number;
        width: "100%";
        minWidth: number;
        height: number;
        margin: number;
    };
    image: {
        flex: number;
        width: "100%";
        height: "100%";
        resizeMode: "cover";
        borderRadius: number;
        backgroundColor: string;
    };
    thumbnail: {
        flex: number;
        width: number;
        height: number;
        borderRadius: number;
    };
    overlay: {
        position: "absolute";
        top: "50%";
        left: "50%";
        transform: ({
            translateX: number;
            translateY?: undefined;
        } | {
            translateY: number;
            translateX?: undefined;
        })[];
    };
    progressBar: {
        marginVertical: number;
    };
    loadingImage: {
        opacity: number;
    };
    loadedImage: {
        opacity: number;
    };
    closeButton: {
        position: "absolute";
        top: number;
        right: number;
        padding: number;
        backgroundColor: string;
        borderRadius: number;
    };
    playButton: {
        width: number;
        height: number;
        borderRadius: number;
        position: "absolute";
        top: "50%";
        left: "50%";
        transform: ({
            translateX: number;
            translateY?: undefined;
        } | {
            translateY: number;
            translateX?: undefined;
        })[];
        zIndex: number;
    };
}>;
//# sourceMappingURL=styles.d.ts.map