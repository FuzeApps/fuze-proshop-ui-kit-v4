export declare const useStyles: () => {
    container: {
        flex: number;
    };
    noResultContainer: {
        flex: number;
        justifyContent: "center";
        alignItems: "center";
        paddingVertical: number;
    };
    noResultText: {
        fontSize: number;
        color: string;
        textAlign: "center";
    };
};
//# sourceMappingURL=AmityCommunitySearchResultComponent.styles.d.ts.map