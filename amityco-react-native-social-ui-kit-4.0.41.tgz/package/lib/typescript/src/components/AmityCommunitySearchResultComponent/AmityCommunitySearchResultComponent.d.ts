import React from 'react';
import { PageID, TabName } from '../../enum';
type AmityCommunitySearchResultComponentType = {
    pageId?: PageID;
    searchResult: Amity.Community[] & Amity.User[];
    searchType: TabName;
    onNextPage: () => void;
    isLoading: boolean;
};
declare const _default: React.NamedExoticComponent<AmityCommunitySearchResultComponentType>;
export default _default;
//# sourceMappingURL=AmityCommunitySearchResultComponent.d.ts.map