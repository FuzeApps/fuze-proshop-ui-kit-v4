import type { MyMD3Theme } from '../../providers/amity-ui-kit-provider';
export declare const useStyles: (theme: MyMD3Theme) => {
    container: {
        alignSelf: "center";
        width: number;
        borderTopWidth: number;
        borderLeftWidth: number;
        borderRightWidth: number;
        borderTopLeftRadius: number;
        borderTopRightRadius: number;
        backgroundColor: string;
        borderColor: string;
        position: "absolute";
        bottom: number;
        paddingBottom: number;
        zIndex: number;
    };
    handleBar: {
        alignSelf: "center";
        width: number;
        backgroundColor: string;
        height: number;
        marginVertical: number;
        borderRadius: number;
    };
    buttonsContainer: {
        paddingTop: number;
        paddingHorizontal: number;
    };
    iconBtn: {
        width: number;
        height: number;
        tintColor: string;
        marginRight: number;
    };
    iconText: {
        color: string;
        fontSize: number;
        fontWeight: "bold";
    };
    mediaAttachmentBtn: {
        flexDirection: "row";
        alignItems: "center";
        marginBottom: number;
    };
};
//# sourceMappingURL=styles.d.ts.map