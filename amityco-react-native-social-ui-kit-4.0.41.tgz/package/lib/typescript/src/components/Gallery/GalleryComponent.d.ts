import React from 'react';
import { FeedRefType } from '../../screens/CommunityHome';
interface IGalleryComponent {
    targetId: string;
    targetType: 'user' | 'community';
}
declare const _default: React.MemoExoticComponent<React.ForwardRefExoticComponent<IGalleryComponent & React.RefAttributes<FeedRefType>>>;
export default _default;
//# sourceMappingURL=GalleryComponent.d.ts.map