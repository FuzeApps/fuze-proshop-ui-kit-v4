import React from 'react';
import { TabName } from '../../enum/tabNameState';
interface IGalleryTab {
    onTabChange: (tabName: TabName) => void;
    tabName: TabName[];
    curerntTab: TabName;
}
declare const _default: React.NamedExoticComponent<IGalleryTab>;
export default _default;
//# sourceMappingURL=GalleryTab.d.ts.map