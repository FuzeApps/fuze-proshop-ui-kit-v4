export declare const useStyles: () => {
    container: {
        flex: number;
        backgroundColor: string;
    };
    loadingIndicator: {
        flex: number;
        justifyContent: "center";
        alignItems: "center";
        position: "absolute";
        top: number;
        bottom: number;
        left: number;
        right: number;
        zIndex: number;
    };
    dotIcon: {
        width: number;
        height: number;
    };
    followIcon: {
        width: number;
        height: number;
        color: string;
    };
    userDetail: {
        flexDirection: "row";
        alignItems: "flex-start";
        backgroundColor: string;
    };
    profileContainer: {
        backgroundColor: string;
        padding: number;
    };
    descriptionContainer: {
        paddingVertical: number;
    };
    descriptionText: {
        paddingVertical: number;
        color: string;
        fontSize: number;
    };
    avatar: {
        width: number;
        height: number;
        borderRadius: number;
        marginRight: number;
    };
    userInfo: {
        marginLeft: number;
        backgroundColor: string;
    };
    title: {
        fontSize: number;
        color: string;
        fontWeight: "bold";
        marginBottom: number;
    };
    horizontalText: {
        flexDirection: "row";
        backgroundColor: string;
    };
    textComponent: {
        marginBottom: number;
        fontSize: number;
        color: string;
    };
    editProfileButton: {
        borderWidth: number;
        borderColor: string;
        padding: number;
        borderRadius: number;
        flexDirection: "row";
        justifyContent: "center";
        alignItems: "center";
    };
    followButton: {
        backgroundColor: string;
        padding: number;
        borderRadius: number;
        flexDirection: "row";
        justifyContent: "center";
        alignItems: "center";
    };
    followText: {
        marginLeft: number;
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    editProfileText: {
        marginLeft: number;
        fontSize: number;
        fontWeight: "600";
        color: string;
    };
    tabContainer: {
        flexDirection: "row";
        alignItems: "center";
        marginVertical: number;
        paddingHorizontal: number;
    };
    tab: {
        paddingHorizontal: number;
        paddingVertical: number;
        borderRadius: number;
        justifyContent: "center";
        alignItems: "center";
        backgroundColor: string;
        marginRight: number;
    };
    focusedTab: {
        backgroundColor: string;
    };
    tabText: {
        color: string;
        fontWeight: "500";
    };
    focusedTabText: {
        color: string;
    };
    emptyContentContainer: {
        height: number;
        justifyContent: "center";
        alignItems: "center";
    };
    emptyContentText: {
        marginTop: number;
        fontSize: number;
        color: string;
    };
    thumbnail: {
        width: number;
        height: number;
        borderRadius: number;
        margin: number;
    };
    playButton: {
        position: "absolute";
        width: "100%";
        height: "100%";
        justifyContent: "center";
        alignItems: "center";
    };
};
//# sourceMappingURL=styles.d.ts.map