import React from 'react';
declare const _default: React.MemoExoticComponent<({ currentTab, }: {
    currentTab: string;
}) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=AmitySocialHomeTopNavigationComponent.d.ts.map