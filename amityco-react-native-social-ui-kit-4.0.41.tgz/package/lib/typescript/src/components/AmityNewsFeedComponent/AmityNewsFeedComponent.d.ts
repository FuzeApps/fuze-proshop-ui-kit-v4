import React from 'react';
import { PageID } from '../../enum/enumUIKitID';
type AmityNewsFeedComponentType = {
    pageId?: PageID;
};
declare const _default: React.NamedExoticComponent<AmityNewsFeedComponentType>;
export default _default;
//# sourceMappingURL=AmityNewsFeedComponent.d.ts.map