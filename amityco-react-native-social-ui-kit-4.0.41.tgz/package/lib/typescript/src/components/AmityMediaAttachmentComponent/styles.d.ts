import type { MyMD3Theme } from '../../providers/amity-ui-kit-provider';
export declare const useStyles: (theme: MyMD3Theme) => {
    container: {
        alignSelf: "center";
        width: number;
        borderTopWidth: number;
        borderLeftWidth: number;
        borderRightWidth: number;
        borderTopLeftRadius: number;
        borderTopRightRadius: number;
        backgroundColor: string;
        borderColor: string;
        position: "absolute";
        bottom: number;
        paddingBottom: number;
    };
    handleBar: {
        alignSelf: "center";
        width: number;
        backgroundColor: string;
        height: number;
        marginVertical: number;
        borderRadius: number;
    };
    buttonsContainer: {
        flexDirection: "row";
        paddingTop: number;
        paddingHorizontal: number;
        width: "100%";
        justifyContent: "space-around";
    };
    iconBtn: {
        width: number;
        height: number;
        tintColor: string;
    };
};
//# sourceMappingURL=styles.d.ts.map