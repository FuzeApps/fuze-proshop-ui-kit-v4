import React from 'react';
import { mediaAttachment } from '../../enum';
type AmityMediaAttachmentComponentType = {
    onPressCamera: () => void;
    onPressImage: () => void;
    onPressVideo: () => void;
    chosenMediaType?: mediaAttachment;
};
declare const _default: React.NamedExoticComponent<AmityMediaAttachmentComponentType>;
export default _default;
//# sourceMappingURL=AmityMediaAttachmentComponent.d.ts.map