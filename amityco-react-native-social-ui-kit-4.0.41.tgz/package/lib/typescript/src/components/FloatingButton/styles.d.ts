export declare const useStyles: () => {
    container: {
        position: "absolute";
        bottom: number;
        right: number;
        flex: number;
    };
    otherFeedContainer: {
        position: "absolute";
        bottom: number;
        right: number;
    };
    button: {
        width: number;
        height: number;
        borderRadius: number;
        backgroundColor: string;
        justifyContent: "center";
        alignItems: "center";
        paddingVertical: number;
        paddingHorizontal: number;
        shadowColor: string;
        shadowOffset: {
            width: number;
            height: number;
        };
        shadowOpacity: number;
        shadowRadius: number;
    };
};
//# sourceMappingURL=styles.d.ts.map