export declare const styles: {
    icon: {
        color: string;
        height: number;
        display: "flex";
        justifyContent: "center";
        alignItems: "center";
    };
    cancelText: {
        fontSize: number;
        color: string;
    };
};
//# sourceMappingURL=styles.d.ts.map