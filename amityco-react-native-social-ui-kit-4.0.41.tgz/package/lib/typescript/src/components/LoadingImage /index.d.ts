import React from 'react';
interface OverlayImageProps {
    source: string;
    onClose?: (originalPath: string) => void;
    onLoadFinish?: (fileId: string, fileUrl: string, fileName: string, index: number, originalPath: string) => void;
    index?: number;
    isUploaded: boolean;
    fileId?: string;
    isEditMode?: boolean;
}
declare const LoadingImage: ({ source, onClose, index, onLoadFinish, isUploaded, fileId, isEditMode, }: OverlayImageProps) => React.JSX.Element;
export default LoadingImage;
//# sourceMappingURL=index.d.ts.map