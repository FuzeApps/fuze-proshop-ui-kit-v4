export declare const createStyles: () => {
    container: {
        flex: number;
        position: "relative";
        maxWidth: number;
        height: number;
        margin: number;
    };
    image: {
        flex: number;
        width: "100%";
        height: "100%";
        resizeMode: "cover";
        borderRadius: number;
    };
    overlay: {
        justifyContent: "center";
        alignItems: "center";
        position: "absolute";
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
    };
    progressBar: {
        marginVertical: number;
    };
    loadingImage: {
        opacity: number;
    };
    loadedImage: {
        opacity: number;
    };
    closeButton: {
        position: "absolute";
        top: number;
        right: number;
        padding: number;
        backgroundColor: string;
        borderRadius: number;
    };
};
//# sourceMappingURL=styles.d.ts.map