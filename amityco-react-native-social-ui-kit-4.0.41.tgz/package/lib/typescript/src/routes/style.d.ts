export declare const useStyles: () => {
    btnWrap: {
        padding: number;
        marginLeft: number;
    };
    dotIcon: {
        width: number;
        height: number;
        marginRight: number;
    };
};
//# sourceMappingURL=style.d.ts.map