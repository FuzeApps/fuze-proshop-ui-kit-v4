import * as React from 'react';
interface INavigator {
    screen?: string;
    useOwnNavigationContainer?: boolean;
}
export default function SocialNavigator({ screen, useOwnNavigationContainer, }: INavigator): React.JSX.Element;
export {};
//# sourceMappingURL=SocialNavigator.d.ts.map